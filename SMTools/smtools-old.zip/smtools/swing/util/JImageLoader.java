// ---------------------------------
// Filename      : JImageLoader.java
// Author        : Sven Maerivoet
// Last modified : 01/02/2004
// Target        : Java VM (1.6)
// ---------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.swing.util;

import java.awt.*;
import javax.swing.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.swing.dialogs.*;

/**
 * The <CODE>JImageLoader</CODE> class provides functionality for loading images.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 01/02/2004
 */
public final class JImageLoader
{
	/****************
	 * CONSTRUCTORS *
	 ****************/

	// prevent instantiation
	private JImageLoader()
	{
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Tries to load an image from a specified file.
	 * 
	 * @param  filename          the name of the image file to load
	 * @param  caller            the object that called this method
	 * @return                   an <CODE>ImageIcon</CODE> object containing the loaded image
	 * @throws FileReadException if an error occurred during the loading of the image
	 * @see    JImageLoader#loadImageIconWithWarning(String,Component,String)
	 */
	public static ImageIcon loadImageIcon(String filename, Component caller) throws FileReadException
	{
		Image image = Toolkit.getDefaultToolkit().getImage(filename);

		// wait until entire image is loaded
		MediaTracker mediaTracker = new MediaTracker(caller);
		mediaTracker.addImage(image,0);
		try {
			mediaTracker.waitForID(0);
		}
		catch (InterruptedException exception) {
			throw (new FileReadException(filename));
		}

		// check if the image loaded correctly
		if ((mediaTracker.statusAll(false) & MediaTracker.ERRORED) != 0) {
			throw (new FileReadException(filename));
		}

		return (new ImageIcon(image));
	}

	/**
	 * Tries to load an image from a specified file.
	 * <P>
	 * If the image could not be loaded, no exception is thrown. Instead, <CODE>null</CODE> is
	 * returned and a warning dialog is shown, containing a message. This message is retrieved
	 * from the {@link Messages} database using the specified key. The filename is automatically
	 * specified as a parameter to this key.
	 * 
	 * @param  filename    the name of the image file to load
	 * @param  caller      the object that called this method
	 * @param  warningKey  the key of the warning message to show when an error occurs during loaden
	 * @return             an <CODE>ImageIcon</CODE> object containing the loaded image
	 * @see    JImageLoader#loadImageIcon(String,Component)
	 */
	public static ImageIcon loadImageIconWithWarning(String filename, Component caller,
			String warningKey)
	{
		try {
			return loadImageIcon(filename,caller);
		}
		catch (FileReadException exc) {
			JWarningDialog.warn(caller,Messages.lookup(warningKey,new String[] {filename}));
			return null;
		}
	}
}
