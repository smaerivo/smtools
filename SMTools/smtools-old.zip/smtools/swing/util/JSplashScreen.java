// ----------------------------------
// Filename      : JSplashScreen.java
// Author        : Sven Maerivoet
// Last modified : 12/07/2005
// Target        : Java VM (1.6)
// ----------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.swing.util;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import smtools.application.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.miscellaneous.*;
import smtools.swing.dialogs.*;

/**
 * The <CODE>JSplashScreen</CODE> class provides a splash screen for Swing based GUIs.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * When visible, the splash screen looks as follows:
 * <P>
 * <UL>
 *   <IMG src="doc-files/splash-screen.png">
 * </UL>
 * <P>
 * As can be seen, there are three main areas:
 * <P>
 * <UL>
 *   <LI>An area where <B>custom content</B> can be shown.</LI>
 *   <P>
 *   <UL>
 *     The custom content is passed as a <CODE>JLabel</CODE> to the <CODE>JSplashScreen</CODE>
 *     object via its constructor. Typically, an image is provided; for visual coherence, we
 *     suggest using an <CODE>JLabel</CODE>/image with a <B>maximum width of 500 pixels</B>.
 *   </UL>
 *   <P>
 *   <LI>The <B>common <I>SMTools</I> area</B> (with the hammer and the spanner).</LI>
 *   <P>
 *   <LI>An area containing <B>status messages</B> and a <B>progress bar</B>.</LI>
 *   <P>
 *   <UL>
 *     The caller updates the status message by invoking the {@link JSplashScreen#setStatusMessage(String)}
 *     method.
 *   </UL>
 * </UL>
 * <P>
 * When the splash screen is shown, an optional soundfile can be played; this soundfile has to
 * adhere to the restrictions outlined in the {@link JSoundStream} class.
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 12/07/2005
 * @see     JStandardGUIApplication
 * @see     JSoundStream
 */
public final class JSplashScreen extends JWindow
{
	// the offset used when the dialog is at the edge of the screen
	private static final int kDialogOffset = 50;

	// the name of the default splash screen's banner
	private static final String kDefaultSplashBannerFilename = "smtools-resources/images/smtools-splash-banner.png";

	// internal datastructures
	private boolean fAvailable;
	private JLabel fEventLabel;
	private JProgressBar fProgressBar;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JSplashScreen</CODE> object with a specified content.
	 * <P>
	 * When a <CODE>JSplashScreen</CODE> object should be created, but not be available,
	 * the caller should specify <CODE>null</CODE> as the value for the <CODE>customSplashScreenContent</CODE>.
	 * <P>
	 * The caller should use <CODE>null</CODE> as the value for the <CODE>soundFilename</CODE>
	 * parameter if no soundfile is to be played.
	 * <P>
	 * <B><U>Important remarks</U></B>
	 * <P>
	 * <UL>
	 *   <LI>If the default background image could not be found, then a warning message is displayed.</LI>
	 *   <P>
	 *   <LI>If the specified soundfile could not be played, it is ignored.</LI>
	 * </UL>
	 *
	 * @param customSplashScreenContent the custom content (typically an image with a maximum dimension of 460x130 pixels)
	 * @param soundFilename             the soundfile to be played (use <CODE>null</CODE> for no sound)
	 * @see   JSplashScreen#isAvailable()
	 */
	public JSplashScreen(JLabel customSplashScreenContent, String soundFilename)
	{
		fAvailable = (customSplashScreenContent != null);

		if (fAvailable) {

			// change the cursor to indicate that the user has to wait
			setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

			JPanel contentPanel = new JPanel();
			setContentPane(contentPanel);

			// create a border around the window's contents
			contentPanel.setLayout(new BorderLayout());

			JPanel panel = null;
			JLabel label = null;
			ImageIcon bannerImage = null;

			try {
				bannerImage = JImageLoader.loadImageIcon(kDefaultSplashBannerFilename,this);
			}
			catch (FileReadException exc) {
				JWarningDialog.warn(this,Messages.lookup("errorSplashScreenBannerNotFound",
						new String[] {kDefaultSplashBannerFilename}));
				fAvailable = false;
				return;
			}

			// use a deep dark blue background color
			contentPanel.setBackground(new Color(0.12f,0.08f,0.67f));

			contentPanel.setLayout(new BorderLayout());
			contentPanel.setBorder(new LineBorder(Color.blue,2));

			panel = new JPanel();
			panel.setBorder(new EmptyBorder(5,5,5,5));
			panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
			panel.setOpaque(false);
			panel.setAlignmentX(Component.CENTER_ALIGNMENT);

			panel.add(Box.createRigidArea(new Dimension(0,20)));

			customSplashScreenContent.setForeground(Color.white);
			customSplashScreenContent.setAlignmentX(Component.CENTER_ALIGNMENT);
			panel.add(customSplashScreenContent);

			panel.add(Box.createRigidArea(new Dimension(0,30)));

			label = new JLabel(bannerImage,JLabel.CENTER);
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			panel.add(label);

			panel.add(Box.createRigidArea(new Dimension(0,20)));

			fEventLabel = new JLabel(Messages.lookup("textSplashScreenMessage",null),JLabel.LEFT);
			fEventLabel.setForeground(Color.white);
			fEventLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			panel.add(fEventLabel);

			panel.add(Box.createRigidArea(new Dimension(0,5)));

			fProgressBar = new JProgressBar(JProgressBar.HORIZONTAL,0,1);
			fProgressBar.setBorderPainted(false);
			fProgressBar.setStringPainted(false);
			fProgressBar.setOpaque(true);
			fProgressBar.setAlignmentX(Component.CENTER_ALIGNMENT);
			fProgressBar.setIndeterminate(true);

			panel.add(fProgressBar);

			contentPanel.add(panel,BorderLayout.CENTER);

			pack();

			// position the splash screen in the middle of the screen
			Dimension splashScreenWindowSize = contentPanel.getPreferredSize();
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

			int xPos = ((int) Math.round(screenSize.getWidth()) / 2) - (splashScreenWindowSize.width / 2);
			int yPos = ((int) Math.round(screenSize.getHeight()) / 2)
					- (splashScreenWindowSize.height / 2);
			if (xPos < kDialogOffset) {
				xPos = kDialogOffset;
			}
			if (yPos < kDialogOffset) {
				yPos = kDialogOffset;
			}
			setLocation(xPos,yPos);

			setVisible(true);

			// if requested, play the specified soundfile
			if (soundFilename != null) {

				try {
					new JSoundStream(soundFilename);
				}
				catch (FileReadException exc) {
					// ignore exception
				}
				catch (SoundPlaybackException exc) {
					// ignore exception
				}
			}
		}
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Returns whether or not the <CODE>JSplashScreen</CODE> object is available.
	 * <P>
	 * This method returns <CODE>false</CODE> when no custom content was specified to the constructor.
	 *
	 * @return <CODE>true</CODE> when the <CODE>JSplashScreen</CODE> object is available, <CODE>false</CODE> otherwise
	 */
	public boolean isAvailable()
	{
		return fAvailable;
	}

	/**
	 * Changes the status message.
	 * <P>
	 *
	 * @param statusMessage the status message
	 */
	public void setStatusMessage(String statusMessage)
	{
		if (fAvailable) {
			fEventLabel.setText(statusMessage);
		}
	}

	/**
	 * Prevents flickering when painting.
	 */
	public boolean imageUpdate(Image img, int flags, int x, int y, int w, int h)
	{
		// only allow repainting of this canvas when the image is completely loaded
		// this prevents flickering
		if ((flags & ALLBITS) != 0) {
			repaint();
		}

		return ((flags & (ALLBITS | ERROR)) == 0);
	}
}
