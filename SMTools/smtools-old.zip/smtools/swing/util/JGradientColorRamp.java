// ---------------------------------------
// Filename      : JGradientColorRamp.java
// Author        : Sven Maerivoet
// Last modified : 08/04/2004
// Target        : Java VM (1.6)
// ---------------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.swing.util;

import java.awt.*;
import javax.swing.*;
import smtools.math.*;

/**
 * The <CODE>JGradientColorRamp</CODE> class provides a gradient color ramp.
 * <P>
 * A gradient color ramp provides a visual display of a bar with a spectrum ranging
 * from blue to green to yellow to red:
 * <P>
 * <UL>
 *   <IMG src="doc-files/gradient-color-ramp.png">
 * </UL>
 * <P>
 * A gradient color ramp can have four orientations:
 * <P>
 * <UL>
 *   <LI>horizontal left to right (see {@link JGradientColorRamp#kHorizontalLeftToRight}),</LI>
 *   <LI>horizontal right to left (see {@link JGradientColorRamp#kHorizontalRightToLeft}),</LI>
 *   <LI>vertical bottom to top (see {@link JGradientColorRamp#kVerticalBottomToTop}),</LI>
 *   <LI>and vertical top to bottom (see {@link JGradientColorRamp#kVerticalTopToBottom}).</LI>
 * </UL>
 * <P>
 * This class has also one static method, which can be used to derive a <CODE>Color</CODE> that
 * is linearly interpolated across the shown spectrum:
 * <P>
 * <UL>
 *  <CODE>Color interpolatedColor = JGradientColorRamp.interpolate(0.6);</CODE>
 * </UL>
 * <P>
 * which corresponds to the following interpolation scheme:
 * <P>
 * <UL>
 *   <IMG src="doc-files/gradient-color-ramp-interpolated.png">
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 * 
 * @author  Sven Maerivoet
 * @version 08/04/2004
 */
public final class JGradientColorRamp extends JPanel
{
	// the different orientations
	/**
	 * Useful constant to specify a horizontally oriented gradient color ramp going from left to right.
	 */
	public static final int kHorizontalLeftToRight = 0;

	/**
	 * Useful constant to specify a horizontally oriented gradient color ramp going from right to left.
	 */
	public static final int kHorizontalRightToLeft = 1;

	/**
	 * Useful constant to specify a vertically oriented gradient color ramp going from bottom to top.
	 */
	public static final int kVerticalBottomToTop = 2;

	/**
	 * Useful constant to specify a vertically oriented gradient color ramp going from top to bottom.
	 */
	public static final int kVerticalTopToBottom = 3;

	// color-ramp preferences
	private static final float kLowerTreshold = 0.35f;
	private static final float kUpperTreshold = 0.65f;
	private static final float kDifference = kUpperTreshold - kLowerTreshold;
	private static final int kDefaultWidth = 100;
	private static final int kDefaultHeight = 20;

	// internal datastructures
	private int fOrientation;
	private int fWidth;
	private int fHeight;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JGradientColorRamp</CODE> object.
	 * <P>
	 * The gradient color ramp has by default a horizontal orientation (going from left
	 * to right) with a width of 100 pixels and a height of 20 pixels.
	 */
	public JGradientColorRamp()
	{
		this(kHorizontalLeftToRight,kDefaultWidth,kDefaultHeight);
	}

	/**
	 * Constructs a <CODE>JGradientColorRamp</CODE> object with the specified orientation and size.
	 *
	 * @param orientation the orientation of the gradient color ramp ({@link JGradientColorRamp#kHorizontalLeftToRight},
	 *                    {@link JGradientColorRamp#kHorizontalRightToLeft}, {@link JGradientColorRamp#kVerticalBottomToTop} or
	 *                    {@link JGradientColorRamp#kVerticalTopToBottom})
	 * @param width       the width of the gradient color ramp (expressed in pixels)
	 * @param height      the height of the gradient color ramp (expressed in pixels)
	 */
	public JGradientColorRamp(int orientation, int width, int height)
	{
		fOrientation = orientation;
		fWidth = width;
		fHeight = height;
		setMinimumSize(getMinimumSize());
		setMaximumSize(getMaximumSize());
		setPreferredSize(getPreferredSize());
		setSize(getPreferredSize());
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 */
	public Dimension getMinimumSize()
	{
		return (new Dimension(fWidth,fHeight));
	}

	/**
	 */
	public Dimension getMaximumSize()
	{
		return (new Dimension(fWidth,fHeight));
	}

	/**
	 */
	public Dimension getPreferredSize()
	{
		return (new Dimension(fWidth,fHeight));
	}

	/**
	 */
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		// draw outline
		g.setColor(Color.black);
		g.drawRect(0,0,fWidth - 1,fHeight - 1);

		// create gradient color ramp
		if (fOrientation == kHorizontalLeftToRight) {

			for (int x = 1; x < (fWidth - 1); ++x) {
				double interpolationValue = ((double) x - 1.0) / ((double) fWidth - 3.0);
				g.setColor(JGradientColorRamp.interpolate(interpolationValue));
				g.drawLine(x,1,x,fHeight - 2);
			}
		}
		else if (fOrientation == kHorizontalRightToLeft) {

			for (int x = 1; x < (fWidth - 1); ++x) {
				double interpolationValue = 1.0 - (((double) x - 1.0) / ((double) fWidth - 3.0));
				g.setColor(JGradientColorRamp.interpolate(interpolationValue));
				g.drawLine(x,1,x,fHeight - 2);
			}
		}
		else if (fOrientation == kVerticalBottomToTop) {

			for (int y = 1; y < (fHeight - 1); ++y) {
				double interpolationValue = 1.0 - (((double) y - 1.0) / ((double) fHeight - 3.0));
				g.setColor(JGradientColorRamp.interpolate(interpolationValue));
				g.drawLine(1,y,fWidth - 2,y);
			}
		}
		else if (fOrientation == kVerticalTopToBottom) {

			for (int y = 1; y < (fHeight - 1); ++y) {
				double interpolationValue = ((double) y - 1.0) / ((double) fHeight - 3.0);
				g.setColor(JGradientColorRamp.interpolate(interpolationValue));
				g.drawLine(1,y,fWidth - 2,y);
			}
		}
	}

	/**
	 * Derives a <CODE>Color</CODE> that is linearly interpolated across a spectrum
	 * going from blue to green to yellow to red.
	 * <P>
	 * Note that the <CODE>normalisedValue</CODE> is clipped in the interval [0,1].
	 *
	 * @param normalisedValue the value to use when interpolating the spectrum
	 */
	public static Color interpolate(double normalisedValue)
	{
		normalisedValue = MathTools.clip(normalisedValue,0.0,1.0);

		float red = 0.0f;
		float green = 0.0f;
		float blue = 0.0f;

		if (normalisedValue <= kLowerTreshold) {
			// interpolate from blue to green
			float t = (float) normalisedValue / kLowerTreshold; // t lies in [0,1]
			red = 0.0f;
			green = t;
			blue = 1.0f - t;
		}
		else if (normalisedValue <= kUpperTreshold) {
			// interpolate from green to yellow
			float t = ((float) normalisedValue - kLowerTreshold) / kDifference; // t lies in [0,1]
			red = t;
			green = 1.0f;
			blue = 0.0f;
		}
		else if (normalisedValue <= 100) {
			// interpolate from yellow to red
			float t = ((float) normalisedValue - kUpperTreshold) / (1.0f - kUpperTreshold); // t lies in [0,1]
			red = 1.0f;
			green = 1.0f - t;
			blue = 0.0f;
		}

		Color color = new Color(red,green,blue);

		return color;
	}
}
