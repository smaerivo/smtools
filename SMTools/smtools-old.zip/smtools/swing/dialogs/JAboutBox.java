// ------------------------------
// Filename      : JAboutBox.java
// Author        : Sven Maerivoet
// Last modified : 03/11/2004
// Target        : Java VM (1.6)
// ------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.swing.dialogs;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.miscellaneous.*;
import smtools.swing.util.*;

/**
 * The <CODE>JAboutBox</CODE> class provides a modal dialog box containing general
 * application information.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * The dialog box is <I>modal</I>, <I>non-resizable</I> and contains an <I>"Ok" button</I>
 * to close it. Here's an example of a complete about box (Microsoft Windows L&F):
 * <P>
 * <UL>
 *   <IMG src="doc-files/about-box-about-windows.png">
 * </UL>
 * As seen in the above image, there can be up to four different tabs: the first tab contains the
 * <B>application's logo and its accompanying about text</B>, the second tab contains a <B>copyright
 * notice</B> (see second image below), the third tab contains the <B>licence information</B> (see third
 * image below) and the fourth tab contains the <B>author's affiliations</B> (see third image below).
 * <P>
 * <UL>
 *   <IMG src="doc-files/about-box-copyright-windows.png">
 * </UL>
 * <P>
 * <UL>
 *   <IMG src="doc-files/about-box-licence-windows.png">
 * </UL>
 * <P>
 * <UL>
 *   <IMG src="doc-files/about-box-affiliations-windows.png">
 * </UL>
 * <P>
 * Typically, <CODE>JAboutBox</CODE> is subclassed, with several methods overridden, allow
 * customisation of each of the previously shown four tabs. The overrideable methods that control
 * these aspects of the visual layout of the dialog box are:
 * <UL>
 *   <LI>{@link JAboutBox#getLogo}</LI>
 *   <LI>{@link JAboutBox#getLogoPosition}</LI>
 *   <LI>{@link JAboutBox#getAboutText}</LI>
 *   <LI>{@link JAboutBox#getCopyrightFilename}</LI>
 *   <LI>{@link JAboutBox#getLicenceFilename}</LI>
 *   <LI>{@link JAboutBox#getAffiliationsLabels}</LI>
 * </UL>
 * <P>
 * In the first tab, the amount of free memory available to the Java Virtual Machine is also shown.
 * <P>
 * Finally, if either {@link JAboutBox#getCopyrightFilename}, {@link JAboutBox#getLicenceFilename},
 * or {@link JAboutBox#getAffiliationsLabels} returns <CODE>null</CODE>, then its corresponding
 * tab is <B>not</B> shown.
 * 
 * @author  Sven Maerivoet
 * @version 03/11/2004
 */
public class JAboutBox extends JDefaultDialog
{
	// the different logo positions
	/**
	 * Useful constant to specify that the logo should be positioned on top of its
	 * accompanying about text.
	 */
	protected static final boolean kLogoAtTop = true;

	/**
	 * Useful constant to specify that the logo should be positioned at the left of its
	 * accompanying about text.
	 */
	protected static final boolean kLogoAtLeft = !kLogoAtTop;

	// some constraints on the visual layout
	private static final int kTextAreaInitialNrOfRows = 20;
	private static final int kTextAreaExcessScrollPaneSpace = 30;

	// the names of the files containing the animation images
	private static final String kJavaCupImageFilename = "smtools-resources/images/javacup-animated.gif";
	private static final String kSwingImageFilename = "smtools-resources/images/swing-animated.gif";

	// internal datastructures
	private static final int kSwingWidth = 64 + 8; // leave 8 pixel border
	private static final int kSwingHeight = 100 + 20 + 8; // leave 8 pixel border
	private static final int kJavaCupWidth = 64 + 8; // leave 8 pixel border
	private static final int kJavaCupHeight = 100 + 20 + 8; // leave 8 pixel border

	// internal datastructures
	private JTabbedPane fTabbedPane;
	private JLabel fAboutTextLabel;
	private JTextArea fLicenceTextArea;
	private JScrollPane fLicenceScrollPane;
	private boolean fCopyrightAvailable;
	private StringBuffer fCopyrightText;
	private boolean fLicenceAvailable;
	private StringBuffer fLicenceText;
	private boolean fAffiliationsAvailable;
	private JScrollPane fAffiliationsScrollPane;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs an about box.
	 * <P>
	 * The about box is inactive at the end of the constructor, so it should explicitly
	 * shown using the {@link JDefaultDialog#activate} method.<BR> 
	 * It's also modal, has a fixed size and a standard "Ok" button.
	 *
	 * @param owner of the frame in which this about box is to be displayed
	 */
	public JAboutBox(JFrame owner)
	{
		super(owner,JDefaultDialog.kModalDialog,JDefaultDialog.kFixedSizeDialog,
				JDefaultDialog.kOkDialogType,null,JDefaultDialog.kPostponeActivation);
	}

	/*********************
	 * PROTECTED METHODS *
	 *********************/

	/**
	 * Returns a <CODE>JLabel</CODE> containing the application's logo.
	 * <P>
	 * A typical logo can span up to 500x200 pixels (when positioned at the top) or
	 * 200x300 pixels (when positioned at the left).
	 * <P>
	 * This method returns <CODE>null</CODE> by default, so in order to
	 * obtain a custom logo, the caller should override this method.
	 *
	 * @return a <CODE>JLabel</CODE> containing the application's logo
	 */
	protected JLabel getLogo()
	{
		return null;
	}

	/**
	 * Returns an <CODE>boolean</CODE> indicating where the application's logo should
	 * be relative to its accompanying about text.
	 * <P>
	 * The following values are allowed:
	 * <UL>
	 *   <LI>{@link JAboutBox#kLogoAtTop}</LI>
	 *   <LI>{@link JAboutBox#kLogoAtLeft}</LI>
	 * </UL>
	 * The default is
	 *
	 * @return a <CODE>JLabel</CODE> containing the application's logo
	 */
	protected boolean getLogoPosition()
	{
		return kLogoAtTop;
	}

	/**
	 * Returns a <CODE>String</CODE> containing the about text displayed together
	 * with the application's logo.
	 * <P>
	 * In order to have some control over the copyright notice's layout, HTML tags
	 * are allowed (except the starting &lt;HTML&gt; and ending &lt;/HTML&gt; tags which	 
	 * are implicitly given by the about box).
	 * <P>
	 * This method returns <CODE>null</CODE> by default, so in order to
	 * obtain a custom text, the caller should override this method.
	 *
	 * @return a <CODE>String</CODE> containing the about text
	 */
	protected String getAboutText()
	{
		return null;
	}

	/**
	 * Returns a <CODE>String</CODE> denoting the filename containing the
	 * application's copyright notice.
	 * <P>
	 * In order to have some control over the copyright notice's layout, HTML tags
	 * are allowed (except the starting &lt;HTML&gt; and ending &lt;/HTML&gt; tags which	 
	 * are implicitly given by the about box).
	 * <P>
	 * This method returns <CODE>null</CODE> by default, so in order to
	 * obtain a custom copyright notice, the caller should override this method.
	 * <P>
	 * If no explicit filename is given, the tab containing the copyright notice will
	 * not be displayed in the about box. 
	 *
	 * @return a <CODE>String</CODE> denoting the filename containg the application's copyright notice
	 */
	protected String getCopyrightFilename()
	{
		return null;
	}

	/**
	 * Returns a <CODE>String</CODE> denoting the filename containing the
	 * application's licence text (e.g., the GNU General Public Licence).
	 * <P>
	 * This method returns <CODE>null</CODE> by default, so in order to
	 * obtain a custom licence text, the caller should override this method.
	 * <P>
	 * <B>Note that this file should only contain plain text</B>.
	 * <P>
	 * If no explicit filename is given, the tab containing the licence text will
	 * not be displayed in the about box. 
	 *
	 * @return a <CODE>String</CODE> denoting the filename containg the application's licence text
	 */
	protected String getLicenceFilename()
	{
		return null;
	}

	/**
	 * Returns an array of <CODE>JLabel</CODE>s containing the author's affiliations.
	 * <P>
	 * This method returns <CODE>null</CODE> by default, so in order to
	 * obtain custom affiliations, the caller should override this method.
	 * <P>
	 * The given affiliations are <CODE>JLabel</CODE>s that can contain text and/or images.
	 * <P>
	 * If no explicit affiliations are given, the tab containing them will
	 * not be displayed in the about box. 
	 *
	 * @return an array of <CODE>JLabel</CODE>s containing the author's affiliations
	 */
	protected JLabel[] getAffiliationsLabels()
	{
		return null;
	}

	/**
	 * Performs custom initialisation of the about box's member fields.
	 * <P>
	 * <B>Note that this method cannot be overridden !</B>
	 */
	protected final void initializeClass(Object[] parameters)
	{
		fCopyrightAvailable = false;
		String copyrightFilename = getCopyrightFilename();
		if (copyrightFilename != null) {

			boolean error = false;
			try {
				// load the license text from the specified file
				TextFileParser copyrightFile = new TextFileParser(copyrightFilename);

				// use a StringBuffer because a String gives memory problems
				fCopyrightText = new StringBuffer();
				fCopyrightText.append("<HTML>");

				while (!copyrightFile.endOfFileReached()) {

					// explicitly append a new-line character
					fCopyrightText.append(copyrightFile.readString() + "<BR>");
				}

				fCopyrightText.append("<HTML>");

				fCopyrightAvailable = true;
			}
			catch (FileDoesNotExistException exc) {
				error = true;
			}
			catch (FileParseException exc) {
				error = true;
			}

			if (error) {
				JWarningDialog.warn(this,Messages.lookup("errorCopyrightInformationFileReadError",
						new String[] {copyrightFilename}));
			}
		}

		fLicenceAvailable = false;
		String licenceFilename = getLicenceFilename();
		if (licenceFilename != null) {

			boolean error = false;
			try {
				// load the license text from the specified file
				TextFileParser licenceFile = new TextFileParser(licenceFilename);

				// use a StringBuffer because a String gives memory problems
				fLicenceText = new StringBuffer();

				while (!licenceFile.endOfFileReached()) {

					// explicitly append a new-line character
					fLicenceText.append(licenceFile.readString() + '\n');
				}

				fLicenceAvailable = true;
			}
			catch (FileDoesNotExistException exc) {
				error = true;
			}
			catch (FileParseException exc) {
				error = true;
			}

			if (error) {
				JWarningDialog.warn(this,Messages.lookup("errorLicenceInformationFileReadError",
						new String[] {licenceFilename}));
			}
		}

		fAffiliationsAvailable = (getAffiliationsLabels() != null);
	}

	/**
	 * Returns the window title of the about box.
	 * <P>
	 * <B>Note that this method cannot be overridden !</B>
	 */
	protected final String getWindowTitle()
	{
		return Messages.lookup("textAboutBoxDialogTitle",null);
	}

	/**
	 * Creates the about box content area.
	 * <P>
	 * <B>Note that this method cannot be overridden !</B>
	 */
	protected final void constructMainPanel(JPanel mainPanel)
	{
		fTabbedPane = new JTabbedPane();

		// create the about pane
		JPanel aboutPane = new JPanel();
		Dimension customSpacing = null;
		if (getLogoPosition() == kLogoAtTop) {
			aboutPane.setLayout(new BoxLayout(aboutPane,BoxLayout.Y_AXIS));
			customSpacing = new Dimension(0,10);
		}
		else {
			aboutPane.setLayout(new BoxLayout(aboutPane,BoxLayout.X_AXIS));
			customSpacing = new Dimension(10,0);
		}
		aboutPane.setAlignmentX(Component.LEFT_ALIGNMENT);
		aboutPane.setAlignmentY(Component.TOP_ALIGNMENT);
		aboutPane.setBorder(new EmptyBorder(0,10,10,10));
		aboutPane.add(Box.createRigidArea(customSpacing));
		JLabel logo = getLogo();
		if (logo != null) {
			aboutPane.add(logo);
			logo.setAlignmentX(Component.LEFT_ALIGNMENT);
			logo.setAlignmentY(Component.TOP_ALIGNMENT);
			aboutPane.add(Box.createRigidArea(customSpacing));
		}
		fAboutTextLabel = new JLabel("");
		fAboutTextLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		fAboutTextLabel.setAlignmentY(Component.TOP_ALIGNMENT);
		updateAboutTextLabel();		
		aboutPane.add(fAboutTextLabel);
		fTabbedPane.addTab(Messages.lookup("textAboutBoxAboutPaneTitle",null),aboutPane);

		// create the copyright pane
		if (fCopyrightAvailable) {
			JPanel copyrightPane = new JPanel();
			copyrightPane.setLayout(new BorderLayout());
			copyrightPane.setBorder(new EmptyBorder(5,5,10,10));
			JPanel northPanel = new JPanel();
			northPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

			// preload the animation images
			ImageIcon javaCupImage = JImageLoader.loadImageIconWithWarning(kJavaCupImageFilename,this,
					"errorAboutBoxImageNotFound");
			ImageIcon swingImage = JImageLoader.loadImageIconWithWarning(kSwingImageFilename,this,
					"errorAboutBoxImageNotFound");

			// show the Java-cup rotating
			JPanel subPanel = new JPanel();
			subPanel.setLayout(new BoxLayout(subPanel,BoxLayout.Y_AXIS));
			JLabel label = new JLabel(javaCupImage,JLabel.CENTER);
			label.setToolTipText(Messages.lookup("tooltipJavaCupImage",null));
			if (javaCupImage != null) {
				label.setBorder(BorderFactory.createEtchedBorder());
			}
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.add(label);
			subPanel.add(Box.createRigidArea(new Dimension(0,10)));
			label = new JLabel("<HTML><B>Java 2 !</B></HTML>",JLabel.CENTER);
			label.setToolTipText(Messages.lookup("tooltipJavaCupImage",null));
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.add(label);
			subPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.setAlignmentY(Component.TOP_ALIGNMENT);
			subPanel.setPreferredSize(new Dimension(kJavaCupWidth,kJavaCupHeight));
			northPanel.add(subPanel);

			// show the Duke swinging
			subPanel = new JPanel();
			subPanel.setLayout(new BoxLayout(subPanel,BoxLayout.Y_AXIS));
			label = new JLabel(swingImage,JLabel.CENTER);
			label.setToolTipText(Messages.lookup("tooltipSwingImage",null));
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.add(label);
			subPanel.add(Box.createRigidArea(new Dimension(0,10)));
			label = new JLabel("<HTML><B>Swing !</B></HTML>",JLabel.CENTER);
			label.setToolTipText(Messages.lookup("tooltipSwingImage",null));
			label.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.add(label);
			subPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
			subPanel.setAlignmentY(Component.TOP_ALIGNMENT);
			subPanel.setPreferredSize(new Dimension(kSwingWidth,kSwingHeight));
			northPanel.add(subPanel);
			copyrightPane.add(northPanel,BorderLayout.NORTH);

			JPanel centerPanel = new JPanel();
			centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
			centerPanel.add(new JLabel(fCopyrightText.toString()));
			copyrightPane.add(centerPanel,BorderLayout.CENTER);

			fTabbedPane.addTab(Messages.lookup("textAboutBoxCopyrightPaneTitle",null),copyrightPane);
		}

		Dimension maximumDimensions = new Dimension(0,0);

		if (fLicenceAvailable) {
			// create the licence pane
			JPanel licencePane = new JPanel();
			licencePane.setLayout(new BorderLayout());
			fLicenceTextArea = new JTextArea(fLicenceText.toString());
			fLicenceTextArea.setRows(kTextAreaInitialNrOfRows);
			fLicenceTextArea.setFont(getFont().deriveFont(12.0f));
			fLicenceTextArea.setCaretPosition(0);
			fLicenceTextArea.setLineWrap(false);
			fLicenceTextArea.setEditable(false);
			// 'disable' the selection colors
			fLicenceTextArea.setSelectedTextColor(Color.black);
			fLicenceTextArea.setSelectionColor(Color.white);

			// make the JTextArea scrollable by embedding it in a JScrollPane
			fLicenceScrollPane = new JScrollPane(fLicenceTextArea);
			fLicenceScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			fLicenceScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

			// make some room for the vertical scrollbar
			maximumDimensions = fLicenceTextArea.getPreferredScrollableViewportSize();
			maximumDimensions.width += kTextAreaExcessScrollPaneSpace;
			fLicenceScrollPane.setPreferredSize(maximumDimensions);
			licencePane.add(fLicenceScrollPane,BorderLayout.CENTER);
			fTabbedPane.addTab(Messages.lookup("textAboutBoxLicencePaneTitle",null),licencePane);
		}

		if (fAffiliationsAvailable) {
		
			JPanel affiliationsPane = new JPanel();
			affiliationsPane.setLayout(new BoxLayout(affiliationsPane,BoxLayout.Y_AXIS));
			affiliationsPane.setBorder(new EmptyBorder(10,10,10,10));
			affiliationsPane.setAlignmentX(Component.LEFT_ALIGNMENT);
			affiliationsPane.setAlignmentY(Component.TOP_ALIGNMENT);

			JLabel[] affiliationsLabels = getAffiliationsLabels();
			for (JLabel affiliationLabel : affiliationsLabels) {
				affiliationLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
				affiliationLabel.setAlignmentY(Component.TOP_ALIGNMENT);
				affiliationsPane.add(affiliationLabel);
				if (affiliationLabel != affiliationsLabels[affiliationsLabels.length - 1]) {
					affiliationsPane.add(Box.createRigidArea(new Dimension(0,15)));
				}
			}	

			// make the affiliations pane scrollable by embedding it in a JScrollPane
			fAffiliationsScrollPane = new JScrollPane(affiliationsPane);
			fAffiliationsScrollPane.setBorder(new EmptyBorder(0,0,0,0));
			fAffiliationsScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			fAffiliationsScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
			fAffiliationsScrollPane.setPreferredSize(maximumDimensions);

			fTabbedPane.addTab(Messages.lookup("textAboutBoxAffiliationsPaneTitle",null),fAffiliationsScrollPane);
		}

		mainPanel.setLayout(new BorderLayout());
		mainPanel.add(fTabbedPane,BorderLayout.CENTER);
	}

	/**
	 * Performs custom initialisation during the about box's activation.
	 * <P>
	 * <B>Note that this method cannot be overridden !</B>
	 */
	protected final void initializeDuringActivation()
	{
		updateAboutTextLabel();

		// always jump to the first tab (logo and about text)
		fTabbedPane.setSelectedIndex(0);

		if (fLicenceAvailable) {

			// always scroll the beginning of the text in the licence tab
			fLicenceTextArea.setCaretPosition(0);
			fLicenceScrollPane.getVerticalScrollBar().setValue(0);
		}

		if (fAffiliationsAvailable) {

			// always scroll the first affiliation in the affiliations tab
			fAffiliationsScrollPane.getVerticalScrollBar().setValue(0);
		}
	}

	/*******************
	 * PRIVATE METHODS *
	 *******************/

	private void updateAboutTextLabel()
	{
		// update the available memory in the about text
		String aboutText = "<HTML>";
		if (getAboutText() != null) {
			aboutText += getAboutText();
		}
		double freeMemory = Runtime.getRuntime().freeMemory() / (1024.0 * 1024.0);
		aboutText += "<BR><BR>" + Messages.lookup("textFreeMemory",null) + ": "
				+ StringTools.convertDoubleToString(freeMemory,2) + " MB";

		aboutText += "<BR>Java VM " + System.getProperty("java.version");
		aboutText += "<BR>" + System.getProperty("java.vendor");
		aboutText += "<BR>" + System.getProperty("os.name") + " (" + System.getProperty("os.arch") + ")</HTML>";

		fAboutTextLabel.setText(aboutText);
	}
}
