// ---------------------------------
// Filename      : JDateChooser.java
// Author        : Sven Maerivoet
// Last modified : 13/02/2004
// Target        : Java VM (1.6)
// ---------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/********************************************************************
 ACKNOWLEDGEMENTS
 ----------------

 The sourcecode related to the for-loops in the setCaptions() method
 is based on Gervase Gallant's DateChooser (Copyright 1999,2000).

 For more details, please refer to:

 URL: http://www.javazoid.com/Datechooser.htm
 E-mail: ggallant@bigfoot.com
 ********************************************************************/

package smtools.swing.dialogs;

import java.awt.event.*;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import smtools.application.util.*;
import smtools.miscellaneous.*;
import smtools.swing.util.*;

/**
 * The <CODE>JDateChooser</CODE> class provides a dialog box for choosing a date.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * The dialog box is <I>modal</I>, <I>non-resizable</I> and contains <I>"Ok"</I> and <I>"Cancel" buttons</I>
 * to close it. Here's an example of a date chooser (Microsoft Windows L&F):
 * <P>
 * <UL>
 *   <IMG src="doc-files/date-chooser-windows.png">
 * </UL>
 * <P>
 * As can be seen, the following features are available:
 * <P>
 * <UL>
 *   <LI>The <B>currently selected date</B> is shown in white.</LI>
 *   <P>
 *   <LI>Whenever the mouse pointer moves over the day numbers of the calendar, they become
 *       <B>clickable buttons</B>. The button currently underneath the mouse pointer
 *       is shown in green (a tooltip containing the full date is shown after
 *       a while).</LI>
 *   <P>
 *   <LI>At the top of the dialog box, a navigational area is present:</LI>
 *   <P>
 *   <UL>
 *     <LI>The <B>outer-left up <IMG src="doc-files/calendar-up-arrow.png" align=center>
 *         and down <IMG src="doc-files/calendar-down-arrow.png" align=center> arrows</B>
 *         turn the calendar to the next, respectively previously, <B>month</B> (which is
 *         shown directly next to them).</LI>
 *     <P>
 *     <LI>The <B>middle up <IMG src="doc-files/calendar-up-arrow.png" align=center> and
 *         down <IMG src="doc-files/calendar-down-arrow.png" align=center> arrows</B>
 *         turn the calendar to the next, respectively previously, <B>year</B> (which is
 *         shown directly next to them).</LI>
 *     <P>
 *     <LI>The optional <B>undo button</B> <IMG src="doc-files/calendar-undo.png" align=center>
 *         resets the calendar to its initial date (and selects it).</LI>
 *     <P>
 *     <LI>The <B>exclamation button</B> <IMG src="doc-files/calendar-exclamation.png" align=center>
 *         moves the calendar to the current date (and selects it).</LI>
 *   </UL>
 * </UL>
 * <P>
 * When the user closes the date chooser's dialog box, its state should be queried as follows:
 * <P>
 * <CODE>
 * <PRE>
 *   if (!myDateChooser.canceled()) {
 *     Date date = myDateChooser.getSelectedDate();
 *     // rest of code
 *   }
 * </PRE>
 * </CODE>
 * <P>
 * <B><U>Important remark</U></B>
 * <P>
 * <UL>
 *   This GUI-component supports <B>caching</B> in the <I>SMTools</I> framework. Using the
 *   {@link JDateChooser#JDateChooser(JFrame,Date,boolean,boolean)} constructor, dialog
 *   activation can be postponed until an explicit call to {@link JDefaultDialog#activate}
 *   is made.
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 13/02/2004
 */
public final class JDateChooser extends JDefaultDialog
{
	// the different default date modes
	/**
	 * Useful constant to allow the use of the <B>undo button</B>
	 * <IMG src="doc-files/calendar-undo.png" align=center>.
	 */
	public static final boolean kEnableDefaultDate = true;

	/**
	 * Useful constant to disable the use of the <B>undo button</B>
	 * <IMG src="doc-files/calendar-undo.png" align=center>.
	 */
	public static final boolean kDisableDefaultDate = !kEnableDefaultDate;

	// the names of the months and the days
	private static final String[] kMonths = {Messages.lookup("textMonthJanuary",null),
			Messages.lookup("textMonthFebruary",null), Messages.lookup("textMonthMarch",null),
			Messages.lookup("textMonthApril",null), Messages.lookup("textMonthMay",null),
			Messages.lookup("textMonthJune",null), Messages.lookup("textMonthJuly",null),
			Messages.lookup("textMonthAugust",null), Messages.lookup("textMonthSeptember",null),
			Messages.lookup("textMonthOctober",null), Messages.lookup("textMonthNovember",null),
			Messages.lookup("textMonthDecember",null)};

	private static final String[] kWeekDays = {Messages.lookup("textDayMonday",null),
			Messages.lookup("textDayTuesday",null), Messages.lookup("textDayWednesday",null),
			Messages.lookup("textDayThursday",null), Messages.lookup("textDayFriday",null),
			Messages.lookup("textDaySaturday",null), Messages.lookup("textDaySunday",null)};

	private static final String[] kWeekDaysAbbreviated = {
			Messages.lookup("textDayMondayAbbreviated",null),
			Messages.lookup("textDayTuesdayAbbreviated",null),
			Messages.lookup("textDayWednesdayAbbreviated",null),
			Messages.lookup("textDayThursdayAbbreviated",null),
			Messages.lookup("textDayFridayAbbreviated",null),
			Messages.lookup("textDaySaturdayAbbreviated",null),
			Messages.lookup("textDaySundayAbbreviated",null)};

	// the number of days in each month
	private static final int[] kDaysInMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	// some sizes
	private static final int kDayButtonSize = 28;
	private static final int kMonthLabelWidth = 70;
	private static final int kYearLabelWidth = 40;
	private static final int kSelectedLabelWidth = 200;

	// some action-commands
	private static final String kDaySelected = "day-selected";
	private static final String kPreviousMonth = "previous-month";
	private static final String kNextMonth = "next-month";
	private static final String kPreviousYear = "previous-year";
	private static final String kNextYear = "next-year";
	private static final String kDefaultDate = "default-date";
	private static final String kCurrentDate = "current-date";

	// internal datastructures
	private JUnfocusableButton fDefaultDateButton;
	private JLabel fShownMonthLabel;
	private JLabel fShownYearLabel;
	private JUnfocusableTriggeredButton[] fDays;
	private JLabel fSelectedDateLabel;
	private Calendar fCalendar;
	private Date fDefaultDate;
	private Date fSelectedDate;
	private boolean fEnableDefaultDate;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JDateChooser</CODE> object and shows it on the screen.
	 *
	 * @param owner             the frame in which this dialog is to be displayed
	 * @param defaultDate       the default <CODE>Date</CODE> used when the calendar is shown
	 * @param enableDefaultDate a <CODE>boolean</CODE> switch for enabling/disabling the use of the default date
	 * @see   JDateChooser#JDateChooser(JFrame,Date,boolean,boolean)
	 */
	public JDateChooser(JFrame owner, Date defaultDate, boolean enableDefaultDate)
	{
		this(owner,defaultDate,enableDefaultDate,JDefaultDialog.kImmediateActivation);
	}

	/**
	 * Constructs a <CODE>JDateChooser</CODE> object and allows postponing of activation.
	 *
	 * @param owner               the frame in which this dialog is to be displayed
	 * @param defaultDate         the default <CODE>Date</CODE> used when the calendar is shown
	 * @param enableDefaultDate   a <CODE>boolean</CODE> flag indicating whether or not the the undo button can be used
	 * @param immediateActivation a <CODE>boolean</CODE> flag indicating whether or not the dialog box should be made
	 *                            visible at the end of the constructor (which can be useful for <B>caching</B>)
	 * @see   JDateChooser#JDateChooser(JFrame,Date,boolean)
	 */
	public JDateChooser(JFrame owner, Date defaultDate, boolean enableDefaultDate,
			boolean immediateActivation)
	{
		super(owner,JDefaultDialog.kModalDialog,JDefaultDialog.kFixedSizeDialog,
				JDefaultDialog.kOkCancelDialogType,new Object[] {defaultDate,
						new Boolean(enableDefaultDate)},immediateActivation);
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	// the action-listener
	/**
	 */
	public void actionPerformed(ActionEvent e)
	{
		super.actionPerformed(e);

		String command = e.getActionCommand();

		if (command.equals(kDaySelected)) {

			JButton dayButton = (JButton) e.getSource();
			String dayString = dayButton.getText();

			if (dayString.length() > 0) {

				int year = fCalendar.get(Calendar.YEAR);
				int month = fCalendar.get(Calendar.MONTH);
				fCalendar.set(year,month,Integer.parseInt(dayString));
				fSelectedDate = fCalendar.getTime();

				setCaptions();
			}
		}
		else {
			setCalendar(e.getActionCommand());
		}
	}

	/**
	 * Returns the currently selected date.
	 *
	 * @return the currently selected date
	 */
	public Date getSelectedDate()
	{
		if (canceled()) {
			return fDefaultDate;
		}
		else {
			return fSelectedDate;
		}
	}

	/**
	 * Sets the default date.
	 * <P>
	 * The default date is initially shown in the calendar, it is furthermore
	 * accessible via the optional <B>undo button</B>
	 * <IMG src="doc-files/calendar-undo.png" align=center>.
	 *
	 * @param date the default date for the date chooser
	 */
	public void setDefaultDate(Date date)
	{
		fDefaultDate = date;
		fSelectedDate = fDefaultDate;
		fCalendar.setTime(fDefaultDate);
		if (fDefaultDateButton != null) {
			fDefaultDateButton.setToolTipText(Messages.lookup("tooltipCalendarCurrentDate",
					new String[] {DateFormatter.getShortDateString(fDefaultDate)}));
		}
		setCaptions();
	}

	/*********************
	 * PROTECTED METHODS *
	 *********************/

	/**
	 */
	protected void initializeClass(Object[] parameters)
	{
		fDefaultDate = (Date) parameters[0];
		fSelectedDate = fDefaultDate;
		fCalendar = Calendar.getInstance();
		fCalendar.setTime(fDefaultDate);
		fEnableDefaultDate = ((Boolean) parameters[1]).booleanValue();
	}

	/**
	 */
	protected final String getWindowTitle()
	{
		return Messages.lookup("textChooseDateDialogTitle",null);
	}

	/**
	 */
	protected void constructMainPanel(JPanel mainPanel)
	{
		JPanel panel = null;
		JPanel subPanel = null;
		JPanel spinPanel = null;
		JLabel label = null;
		JUnfocusableTriggeredButton dayButton = null;
		JUnfocusableButton navButton = null;

		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBorder(new EmptyBorder(10,0,10,0));

		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));

		subPanel = new JPanel();
		subPanel.setLayout(new FlowLayout(FlowLayout.CENTER,0,0));

		spinPanel = new JPanel();
		spinPanel.setLayout(new BoxLayout(spinPanel,BoxLayout.Y_AXIS));

		// show the navigation button for the next month
		navButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/up.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setBorder(new EmptyBorder(0,0,0,0));
		navButton.setFocusPainted(false);
		navButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/up-hl.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setRolloverEnabled(true);
		navButton.setToolTipText(Messages.lookup("tooltipCalendarNextMonth",null));
		navButton.setActionCommand(kNextMonth);
		navButton.addActionListener(this);
		spinPanel.add(navButton);

		// show the navigation button for the previous month
		navButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/down.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setBorder(new EmptyBorder(0,0,0,0));
		navButton.setFocusPainted(false);
		navButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/down-hl.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setRolloverEnabled(true);
		navButton.setToolTipText(Messages.lookup("tooltipCalendarPreviousMonth",null));
		navButton.setActionCommand(kPreviousMonth);
		navButton.addActionListener(this);
		spinPanel.add(navButton);
		subPanel.add(spinPanel);

		// create a small gap
		subPanel.add(Box.createRigidArea(new Dimension(5,0)));

		// show the calendar's current month
		fShownMonthLabel = new JLabel(kMonths[fCalendar.get(Calendar.MONTH)],JLabel.LEFT);
		fShownMonthLabel.setPreferredSize(new Dimension(kMonthLabelWidth,25));
		subPanel.add(fShownMonthLabel);

		// create a small gap
		subPanel.add(Box.createRigidArea(new Dimension(10,0)));

		spinPanel = new JPanel();
		spinPanel.setLayout(new BoxLayout(spinPanel,BoxLayout.Y_AXIS));

		// show the navigation button for the next year
		navButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/up.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setBorder(new EmptyBorder(0,0,0,0));
		navButton.setFocusPainted(false);
		navButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/up-hl.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setRolloverEnabled(true);
		navButton.setToolTipText(Messages.lookup("tooltipCalendarNextYear",null));
		navButton.setActionCommand(kNextYear);
		navButton.addActionListener(this);
		spinPanel.add(navButton);

		// show the navigation button for the previous year
		navButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/down.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setBorder(new EmptyBorder(0,0,0,0));
		navButton.setFocusPainted(false);
		navButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/down-hl.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setRolloverEnabled(true);
		navButton.setToolTipText(Messages.lookup("tooltipCalendarPreviousYear",null));
		navButton.setActionCommand(kPreviousYear);
		navButton.addActionListener(this);
		spinPanel.add(navButton);
		subPanel.add(spinPanel);

		// create a small gap
		subPanel.add(Box.createRigidArea(new Dimension(5,0)));

		// show the calendar's current year
		fShownYearLabel = new JLabel(String.valueOf(fCalendar.get(Calendar.YEAR)),JLabel.LEFT);
		fShownYearLabel.setPreferredSize(new Dimension(kYearLabelWidth,25));
		subPanel.add(fShownYearLabel);

		// create a small gap
		subPanel.add(Box.createRigidArea(new Dimension(20,0)));

		if (fEnableDefaultDate) {
			fDefaultDateButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/undo.gif",this,"errorGUIComponentImageNotFound"));
			fDefaultDateButton.setBorder(new EmptyBorder(0,0,0,0));
			fDefaultDateButton.setFocusPainted(false);
			fDefaultDateButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/undo-hl.gif",this,"errorGUIComponentImageNotFound"));
			fDefaultDateButton.setRolloverEnabled(true);
			fDefaultDateButton.setToolTipText(Messages.lookup("tooltipCalendarCurrentDate",
					new String[] {DateFormatter.getShortDateString(fDefaultDate)}));
			fDefaultDateButton.setActionCommand(kDefaultDate);
			fDefaultDateButton.addActionListener(this);
			subPanel.add(fDefaultDateButton);

			// create a small gap
			subPanel.add(Box.createRigidArea(new Dimension(10,0)));
		}

		navButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/exclamation.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setBorder(new EmptyBorder(0,0,0,0));
		navButton.setFocusPainted(false);
		navButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/exclamation-hl.gif",this,"errorGUIComponentImageNotFound"));
		navButton.setRolloverEnabled(true);
		navButton.setToolTipText(Messages.lookup("tooltipCalendarExclamation",
				new String[] {DateFormatter.getShortDateString(new Date())}));
		navButton.setActionCommand(kCurrentDate);
		navButton.addActionListener(this);
		subPanel.add(navButton);

		panel.add(subPanel);
		panel.add(new JEtchedLine());

		mainPanel.add(panel,BorderLayout.NORTH);

		// show the first letters of the weekdays
		panel = new JPanel();
		panel.setLayout(new GridLayout(0,7));
		panel.setBorder(new EmptyBorder(10,10,10,9));
		for (int i = 0; i < 7; ++i) {
			label = new JLabel(kWeekDaysAbbreviated[i],JLabel.CENTER);
			label.setFont(label.getFont().deriveFont(Font.ITALIC).deriveFont(12.0f));
			label.setForeground(Color.blue);
			panel.add(label);
		}

		// show the days' buttons
		fDays = new JUnfocusableTriggeredButton[35];
		for (int i = 0; i < 35; i++) {
			dayButton = new JUnfocusableTriggeredButton(String.valueOf(i));
			dayButton.setPreferredSize(new Dimension(kDayButtonSize,kDayButtonSize));
			dayButton.setActionCommand(kDaySelected);
			dayButton.addActionListener(this);
			fDays[i] = dayButton;
			fDays[i].setHighlightColor(Color.green);
			fDays[i].setSelectedColor(Color.white);
			panel.add(fDays[i]);
		}
		mainPanel.add(panel,BorderLayout.CENTER);

		// show the label with the selected date
		panel = new JPanel();
		panel.setLayout(new FlowLayout());
		fSelectedDateLabel = new JLabel(DateFormatter.getLongDateString(fDefaultDate),JLabel.CENTER);
		Border emptyBorder = new EmptyBorder(10,10,10,9);
		Border etchedBorder = new EtchedBorder();
		fSelectedDateLabel.setBorder(new CompoundBorder(etchedBorder,emptyBorder));
		panel.add(fSelectedDateLabel);
		mainPanel.add(panel,BorderLayout.SOUTH);

		setCaptions();
	}

	/*******************
	 * PRIVATE METHODS *
	 *******************/

	private void setCaptions()
	{
		// deselect all day-buttons
		for (int i = 0; i < 35; i++) {
			fDays[i].setSelected(false);
		}

		// remember the currently selected date
		Date tempDate = fCalendar.getTime();

		fCalendar.setTime(fSelectedDate);
		int selectedYear = fCalendar.get(Calendar.YEAR);
		int selectedMonth = fCalendar.get(Calendar.MONTH);
		int selectedDay = fCalendar.get(Calendar.DATE);

		fCalendar.setTime(tempDate);
		int currentYear = fCalendar.get(Calendar.YEAR);
		int currentMonth = fCalendar.get(Calendar.MONTH);

		// set month label
		String monthName = kMonths[fCalendar.get(Calendar.MONTH)].substring(0,1).toUpperCase()
				+ kMonths[fCalendar.get(Calendar.MONTH)].substring(1);
		fShownMonthLabel.setText(monthName);
		fShownMonthLabel.setFont(fShownMonthLabel.getFont().deriveFont(Font.BOLD).deriveFont(12.0f));

		// set year label
		fShownYearLabel.setText(String.valueOf(fCalendar.get(Calendar.YEAR)));
		fShownYearLabel.setFont(fShownYearLabel.getFont().deriveFont(Font.BOLD).deriveFont(12.0f));

		// set calendar to the first day of the month
		fCalendar.set(currentYear,currentMonth,1);

		// find the day-of-week for the first day of the month
		// subtract one because we start with Monday instead of Sunday
		int startPos = fCalendar.get(Calendar.DAY_OF_WEEK) - 1;
		if (startPos == 0) {
			startPos = 7;
		}

		// fill in all the labels
		for (int i = (startPos - 1); i < fDays.length; ++i) {

			fDays[i].setVisible(true);
			fDays[i].setText(String.valueOf(fCalendar.get(Calendar.DATE)));

			// allow the selected date to be highlighted
			if ((currentYear == selectedYear) && (currentMonth == selectedMonth)
					&& (fCalendar.get(Calendar.DATE) == selectedDay)) {
				fDays[i].setSelected(true);
			}

			fDays[i].setToolTipText(kWeekDays[i % 7].substring(0,1).toUpperCase()
					+ kWeekDays[i % 7].substring(1) + ", " + String.valueOf(fCalendar.get(Calendar.DATE))
					+ " " + fShownMonthLabel.getText().substring(0,1).toLowerCase()
					+ fShownMonthLabel.getText().substring(1) + " "
					+ String.valueOf(fCalendar.get(Calendar.YEAR)));

			// advance calendar to the next day
			fCalendar.roll(Calendar.DATE,true);

			// stop advancing when the beginning of the next month is reached
			if (fCalendar.get(Calendar.DATE) == 1) {

				// clear remaining labels
				for (int j = (i + 1); j < fDays.length; j++) {
					fDays[j].setVisible(false);
				}

				break;
			}
		}

		// complete first week
		for (int i = 0; i < (startPos - 1); ++i) {

			fDays[i].setVisible(true);

			// allow the selected date to be highlighted
			if ((currentYear == selectedYear) && (currentMonth == selectedMonth)
					&& (fCalendar.get(Calendar.DATE) == selectedDay)) {
				fDays[i].setSelected(true);
			}

			fDays[i].setToolTipText(kWeekDays[i % 7].substring(0,1).toUpperCase()
					+ kWeekDays[i % 7].substring(1) + ", " + String.valueOf(fCalendar.get(Calendar.DATE))
					+ " " + fShownMonthLabel.getText().substring(0,1).toLowerCase()
					+ fShownMonthLabel.getText().substring(1) + " "
					+ String.valueOf(fCalendar.get(Calendar.YEAR)));

			if (fCalendar.get(Calendar.DATE) > 25) {
				fDays[i].setText(String.valueOf(fCalendar.get(Calendar.DATE)));

				// advance calendar to the next day
				fCalendar.roll(Calendar.DATE,true);
			}
			else {
				fDays[i].setVisible(false);
			}
		}

		// adjust the label showing the currently selected date
		fSelectedDateLabel.setText(DateFormatter.getLongDateString(fSelectedDate));
		fSelectedDateLabel.setFont(fSelectedDateLabel.getFont().deriveFont(Font.BOLD).deriveFont(12.0f));
		fSelectedDateLabel.setPreferredSize(new Dimension(kSelectedLabelWidth,30));
	}

	private void setCalendar(String actionCommand)
	{
		if (actionCommand.equals(kPreviousMonth)) {
			int selectedDay = getCurrentlySelectedDay();
			fCalendar.add(Calendar.MONTH,-1);
			fCalendar.set(Calendar.DATE,preventDateOverlow(selectedDay));
			fSelectedDate = fCalendar.getTime();
		}
		else if (actionCommand.equals(kNextMonth)) {
			int selectedDay = getCurrentlySelectedDay();
			fCalendar.add(Calendar.MONTH,1);
			fCalendar.set(Calendar.DATE,preventDateOverlow(selectedDay));
			fSelectedDate = fCalendar.getTime();
		}
		else if (actionCommand.equals(kPreviousYear)) {
			int selectedDay = getCurrentlySelectedDay();
			fCalendar.add(Calendar.YEAR,-1);
			fCalendar.set(Calendar.DATE,preventDateOverlow(selectedDay));
			fSelectedDate = fCalendar.getTime();
		}
		else if (actionCommand.equals(kNextYear)) {
			int selectedDay = getCurrentlySelectedDay();
			fCalendar.add(Calendar.YEAR,1);
			fCalendar.set(Calendar.DATE,preventDateOverlow(selectedDay));
			fSelectedDate = fCalendar.getTime();
		}
		else if (actionCommand.equals(kDefaultDate)) {
			fSelectedDate = fDefaultDate;
			fCalendar.setTime(fSelectedDate);
		}
		else if (actionCommand.equals(kCurrentDate)) {
			fSelectedDate = new Date();
			fCalendar.setTime(fSelectedDate);
		}

		setCaptions();
	}

	private int getCurrentlySelectedDay()
	{
		Date tempDate = fCalendar.getTime();
		fCalendar.setTime(fSelectedDate);
		int selectedDay = fCalendar.get(Calendar.DATE);
		fCalendar.setTime(tempDate);
		return selectedDay;
	}

	private int preventDateOverlow(int selectedDay)
	{
		// find the last day of the current month
		int lastDayOfMonth = kDaysInMonth[fCalendar.get(Calendar.MONTH)];
		if ((fCalendar.get(Calendar.MONTH) == 1)
				&& (((GregorianCalendar) fCalendar).isLeapYear(fCalendar.get(Calendar.YEAR)))) {
			lastDayOfMonth = 29;
		}

		// check for overflow
		if (selectedDay > lastDayOfMonth) {
			return lastDayOfMonth;
		}
		else {
			return selectedDay;
		}
	}
}
