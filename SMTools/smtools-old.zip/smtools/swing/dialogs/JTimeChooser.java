// ---------------------------------
// Filename      : JTimeChooser.java
// Author        : Sven Maerivoet
// Last modified : 30/10/2004
// Target        : Java VM (1.6)
// ---------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.swing.dialogs;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.math.*;
import smtools.miscellaneous.*;
import smtools.swing.util.*;

/**
 * The <CODE>JTimeChooser</CODE> class provides a dialog box for choosing a time.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * The dialog box is <I>modal</I>, <I>non-resizable</I> and contains <I>"Ok"</I> and <I>"Cancel" buttons</I>
 * to close it. Here's an example of a time chooser (Microsoft Windows L&F):
 * <P>
 * <UL>
 *   <IMG src="doc-files/time-chooser-windows.png">
 * </UL>
 * <P>
 * As can be seen, the time chooser's GUI consists of two main areas:
 * <P>
 * <UL>
 *   <LI>An <B>analogue clock</B> showing the currently selected hour, minute and second. An
 *       <B>optional digital clock</B> can also be shown in the clock's panel. Both clocks are
 *       updated in real-time.</LI>
 *   <P>
 *   <LI>Four <B>combo-boxes</B> for selecting the hour, minute, second and millisecond.</LI>
 *   <P>
 * </UL>
 * There's also the <B>exclamation button</B> <IMG src="doc-files/calendar-exclamation.png" align=center>
 * that jumps to the current time (and selects it).
 * <P>
 * Depending on the desired functionality, the time chooser can be allowed to select only:
 * <P>
 * <UL>
 *   <LI>the hour and minute,</LI>
 *   <LI>the hour, minute and second,</LI>
 *   <LI>or the hour, minute, second and millisecond.</LI>
 * </UL>
 * <P>
 * When the user closes the time chooser's dialog box, its state should be queried as follows:
 * <P>
 * <CODE>
 * <PRE>
 *   if (!myTimeChooser.canceled()) {
 *     Time time = myTimeChooser.getSelectedTime();
 *     // rest of code
 *   }
 * </PRE>
 * </CODE>
 * <P>
 * The clock's digits can be set to either always show the numbers 1 to 12, or to show the
 * numbers 1 to 12 and 13 to 24 in the AM and PM time periods respectively.
 * <P>
 * <B><U>Important remark</U></B>
 * <P>
 * <UL>
 *   This GUI-component supports <B>caching</B> in the <I>SMTools</I> framework. Using the
 *   {@link JTimeChooser#JTimeChooser(JFrame,Time,int,boolean,boolean,boolean)} constructor, dialog
 *   activation can be postponed until an explicit call to {@link JDefaultDialog#activate}
 *   is made.
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 30/10/2004
 * @see     Time
 */
public final class JTimeChooser extends JDefaultDialog
{
	// the different time chooser types
	/**
	 * Useful constant to specify a time chooser for selecting only the hour and minute.
	 */
	public static final int kHourMinuteType = 1;

	/**
	 * Useful constant to specify a time chooser for selecting only the hour, minute and second.
	 */
	public static final int kHourMinuteSecondType = 2;

	/**
	 * Useful constant to specify a time chooser for selecting the hour, minute, second and millisecond.
	 */
	public static final int kHourMinuteSecondMillisecondType = 3;

	/**
	 * Useful constant to specify that the clock's digits should always be numbered from 1 to 12
	 */
	public static final boolean kUse12HourClockDigits = true;

	/**
	 * Useful constant to specify that the clock's digits should be numbered from 1 to 12 in the AM,
	 * and from 13 to 24 in the PM. 
	 */
	public static final boolean kUse24HourClockDigits = !kUse12HourClockDigits;

	/**
	 * Useful constant to specify a time chooser that shows a clock which is updated continuously.
	 */
	public static final boolean kContinuousUpdate = true;

	/**
	 * Useful constant to specify a time chooser that shows a clock which is updated in second time steps.
	 */
	public static final boolean kDiscreteUpdate = !kContinuousUpdate;

	/**
	 * Useful constant to specify whether or not a digital indication of the current time should be shown.
	 */
	public static final boolean kShowDigitalClock = true;

	// an action-command
	private static final String kCurrentTime = "current-time";

	// internal datastructures
	private Time fTime;
	private int fTimeChooserType;
	private boolean fUse12HourClockDigits;
	private boolean fContinuousUpdate;
	private boolean fShowDigitalClock;
	private ClockPanel fClockPanel;
	private JComboBox fcbHour;
	private JComboBox fcbMinute;
	private JComboBox fcbSecond;
	private JComboBox fcbMillisecond;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JTimeChooser</CODE> object and shows it on the screen.
	 * <P>
	 * Depending on the desired functionality, the time chooser can be allowed to select only:
	 * <P>
	 * <UL>
	 *   <LI>the hour and minute,</LI>
	 *   <LI>the hour, minute and second,</LI>
	 *   <LI>or the hour, minute, second and millisecond.</LI>
	 * </UL>
	 *
	 * @param owner                the frame in which this dialog is to be displayed
	 * @param time                 the initial <CODE>Time</CODE> used when the time chooser is shown
	 * @param timeChooserType      the type of time chooser
	 * @param use12HourClockDigits a <CODE>boolean</CODE> flag indicating whether or not the clock's digits should
	 *                             always be numbered from 1 to 12, or from 1 to 12 and 13 to 24 in AM and PM
	 *                             respectively
	 * @param continuousUpdate     a <CODE>boolean</CODE> flag indicating whether or not the clock's hands should
	 *                             be updated continuously
	 * @param showDigitalClock     a <CODE>boolean</CODE> flag indicating whether or not a digital indication of
	 *                             the current time should be shown
	 * @see   JTimeChooser#JTimeChooser(JFrame,Time,int,boolean,boolean,boolean)
	 * @see   JTimeChooser#kHourMinuteType
	 * @see   JTimeChooser#kHourMinuteSecondType
	 * @see   JTimeChooser#kHourMinuteSecondMillisecondType
	 */
	public JTimeChooser(JFrame owner, Time time, int timeChooserType, boolean use12HourClockDigits,
			boolean continuousUpdate, boolean showDigitalClock)
	{
		this(owner,time,timeChooserType,JDefaultDialog.kImmediateActivation,use12HourClockDigits,
				continuousUpdate,showDigitalClock);
	}

	/**
	 * Constructs a <CODE>JTimeChooser</CODE> object and allows postponing of activation.
	 * <P>
	 * Depending on the desired functionality, the time chooser can be allowed to select only:
	 * <P>
	 * <UL>
	 *   <LI>the hour and minute,</LI>
	 *   <LI>the hour, minute and second,</LI>
	 *   <LI>or the hour, minute, second and millisecond.</LI>
	 * </UL>
	 *
	 * @param owner                the frame in which this dialog is to be displayed
	 * @param time                 the initial <CODE>Time</CODE> used when the time chooser is shown
	 * @param timeChooserType      the type of time chooser
	 * @param use12HourClockDigits a <CODE>boolean</CODE> flag indicating whether or not the clock's digits should
	 *                             always be numbered from 1 to 12, or from 1 to 12 and 13 to 24 in AM and PM
	 *                             respectively
	 * @param continuousUpdate     a <CODE>boolean</CODE> flag indicating whether or not the clock's hands should
	 *                             be updated continuously
	 * @param showDigitalClock     a <CODE>boolean</CODE> flag indicating whether or not a digital indication of
	 *                             the current time should be shown
	 * @param immediateActivation  a <CODE>boolean</CODE> flag indicating whether or not the dialog box should be made
	 *                             visible at the end of the constructor (which can be useful for <B>caching</B>)
	 * @see   JTimeChooser#JTimeChooser(JFrame,Time,int,boolean,boolean,boolean)
	 * @see   JTimeChooser#kHourMinuteType
	 * @see   JTimeChooser#kHourMinuteSecondType
	 * @see   JTimeChooser#kHourMinuteSecondMillisecondType
	 */
	public JTimeChooser(JFrame owner, Time time, int timeChooserType, boolean use12HourClockDigits,
			boolean continuousUpdate, boolean showDigitalClock, boolean immediateActivation)
	{
		super(owner,JDefaultDialog.kModalDialog,JDefaultDialog.kFixedSizeDialog,
				JDefaultDialog.kOkCancelDialogType,new Object[] {time, new Integer(timeChooserType),
						new Boolean(use12HourClockDigits), new Boolean(continuousUpdate),
						new Boolean(showDigitalClock)},immediateActivation);
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	// the action-listener
	/**
	 */
	public void actionPerformed(ActionEvent e)
	{
		super.actionPerformed(e);

		String command = e.getActionCommand();

		if (command.equalsIgnoreCase(kCurrentTime)) {
			fTime.setCurrentTime();

			if ((fTimeChooserType == kHourMinuteType) || (fTimeChooserType == kHourMinuteSecondType)) {
				fTime.fMillisecond = 0;
			}
			if (fTimeChooserType == kHourMinuteType) {
				fTime.fSecond = 0;
			}
			fcbHour.setSelectedIndex(fTime.fHour);
			fcbMinute.setSelectedIndex(fTime.fMinute);
			fcbSecond.setSelectedIndex(fTime.fSecond);
			fcbMillisecond.setSelectedIndex(fTime.fMillisecond);
			fClockPanel.repaint();
		}
		else {
			if (e.getSource() == fcbHour) {
				fTime.fHour = fcbHour.getSelectedIndex();
			}
			else if (e.getSource() == fcbMinute) {
				fTime.fMinute = fcbMinute.getSelectedIndex();
			}
			else if (e.getSource() == fcbSecond) {
				fTime.fSecond = fcbSecond.getSelectedIndex();
			}
			else if (e.getSource() == fcbMillisecond) {
				fTime.fMillisecond = fcbMillisecond.getSelectedIndex();
			}

			fClockPanel.repaint();
		}
	}

	/**
	 * Returns the currently selected time.
	 *
	 * @return the currently selected time
	 */
	public Time getSelectedTime()
	{
		return fTime;
	}

	/**
	 * Sets the default time.
	 * <P>
	 * The default time is initially shown in the time chooser.
	 *
	 * @param time the default Time for the time chooser
	 */
	public void setDefaultTime(Time time)
	{
		fTime = time;
		fcbHour.setSelectedIndex(fTime.fHour);
		fcbMinute.setSelectedIndex(fTime.fMinute);
		fcbSecond.setSelectedIndex(fTime.fSecond);
		fcbMillisecond.setSelectedIndex(fTime.fMillisecond);
	}

	/*********************
	 * PROTECTED METHODS *
	 *********************/

	/**
	 */
	protected void initializeClass(Object[] parameters)
	{
		fTime = new Time((Time) parameters[0]);
		fTimeChooserType = ((Integer) parameters[1]).intValue();
		fUse12HourClockDigits = ((Boolean) parameters[2]).booleanValue();
		fContinuousUpdate = ((Boolean) parameters[3]).booleanValue();
		fShowDigitalClock = ((Boolean) parameters[4]).booleanValue();
	}

	/**
	 */
	protected final String getWindowTitle()
	{
		return Messages.lookup("textChooseTimeDialogTitle",null);
	}

	/**
	 */
	protected void constructMainPanel(JPanel mainPanel)
	{
		JPanel panel = null;
		JUnfocusableButton unfocusableButton = null;
		String dummy = "";

		mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
		mainPanel.setBorder(new EmptyBorder(5,5,5,5));

		// add the clock panel
		fClockPanel = new ClockPanel(fContinuousUpdate,fShowDigitalClock);
		fClockPanel.setToolTipText(Messages.lookup("tooltipClockPanel",null));
		mainPanel.add(fClockPanel);

		mainPanel.add(new JEtchedLine());

		// add the time controls
		panel = new JPanel();
		panel.setLayout(new FlowLayout(FlowLayout.CENTER));
		unfocusableButton = new JUnfocusableButton(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/exclamation.gif",this,"errorGUIComponentImageNotFound"));
		unfocusableButton.setBorder(new EmptyBorder(0,0,0,0));
		unfocusableButton.setFocusPainted(false);
		unfocusableButton.setRolloverIcon(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/exclamation-hl.gif",this,"errorGUIComponentImageNotFound"));
		unfocusableButton.setRolloverEnabled(true);
		unfocusableButton.setToolTipText(Messages.lookup("tooltipGetCurrentTime",null));
		unfocusableButton.setActionCommand(kCurrentTime);
		unfocusableButton.addActionListener(this);
		panel.add(unfocusableButton);

		Vector<String> hours = new Vector<String>();
		for (int i = 0; i < 24; ++i) {
			dummy = String.valueOf(i);
			if (i < 10) {
				dummy = "0" + dummy;
			}
			hours.add(dummy);
		}
		fcbHour = new JComboBox(hours);
		fcbHour.addActionListener(this);
		fcbHour.setSelectedIndex(fTime.fHour);
		fcbHour.setToolTipText(Messages.lookup("tooltipSetHour",null));
		panel.add(fcbHour);
		panel.add(new JLabel("<HTML><B>:</B></HTML>"));

		Vector<String> minutes = new Vector<String>();
		for (int i = 0; i < 60; ++i) {
			dummy = String.valueOf(i);
			if (i < 10) {
				dummy = "0" + dummy;
			}
			minutes.add(dummy);
		}
		fcbMinute = new JComboBox(minutes);
		fcbMinute.addActionListener(this);
		fcbMinute.setSelectedIndex(fTime.fMinute);
		fcbMinute.setToolTipText(Messages.lookup("tooltipSetMinute",null));
		panel.add(fcbMinute);
		panel.add(new JLabel("<HTML><B>:</B></HTML>"));

		Vector<String> seconds = new Vector<String>();
		for (int i = 0; i < 60; ++i) {
			dummy = String.valueOf(i);
			if (i < 10) {
				dummy = "0" + dummy;
			}
			seconds.add(dummy);
		}
		fcbSecond = new JComboBox(seconds);
		fcbSecond.addActionListener(this);
		fcbSecond.setSelectedIndex(fTime.fSecond);
		fcbSecond.setToolTipText(Messages.lookup("tooltipSetSecond",null));
		if (fTimeChooserType == kHourMinuteType) {
			fcbSecond.setEnabled(false);
		}
		panel.add(fcbSecond);
		panel.add(new JLabel("<HTML><B>.</B></HTML>"));

		Vector<String> milliseconds = new Vector<String>();
		for (int i = 0; i < 1000; ++i) {
			dummy = String.valueOf(i);
			if (i < 100) {
				dummy = "0" + dummy;
			}
			if (i < 10) {
				dummy = "0" + dummy;
			}
			milliseconds.add(dummy);
		}
		fcbMillisecond = new JComboBox(milliseconds);
		fcbMillisecond.addActionListener(this);
		fcbMillisecond.setSelectedIndex(fTime.fMillisecond);
		fcbMillisecond.setToolTipText(Messages.lookup("tooltipSetMillisecond",null));
		if ((fTimeChooserType == kHourMinuteType) || (fTimeChooserType == kHourMinuteSecondType)) {
			fcbMillisecond.setEnabled(false);
		}
		panel.add(fcbMillisecond);

		// enlarge panel so that all combo boxes fit inside
		Dimension dimension = panel.getPreferredSize();
		panel.setPreferredSize(new Dimension(dimension.width + 30,dimension.height));
		mainPanel.add(panel);
	}

	/*****************
	 * INNER CLASSES *
	 *****************/

	/** @author Sven Maerivoet<BR>
	 All rights reserved.<BR>
	 */
	private final class ClockPanel extends JPanel implements MouseListener, MouseMotionListener
	{
		// the clock's update period
		private static final int kContinuousUpdatePeriod = 50;
		private static final int kDiscreteUpdatePeriod = 500;

		// the dialog's size
		private static final int kClockWidth = 250;
		private static final int kClockHeight = kClockWidth;

		// internal datastructures
		private boolean fContinuousUpdate;
		private boolean fShowDigitalClock;
		private Time fCurrentTime;
		private int fCenterX;
		private int fCenterY;
		private int fSecondsRadiusZone;

		/****************
		 * CONSTRUCTORS *
		 ****************/

		public ClockPanel(boolean continuousUpdate, boolean showDigitalClock)
		{
			fContinuousUpdate = continuousUpdate;
			fShowDigitalClock = showDigitalClock;

			fCurrentTime = new Time();
			setPreferredSize(new Dimension(kClockWidth,kClockHeight));

			// disable the mouse (motion) listeners
			/*
			 addMouseListener(this);
			 addMouseMotionListener(this);
			 */

			// create a Swing timer to periodically update the clock's display
			Action updateClockPanelAction = new AbstractAction()
			{
				public void actionPerformed(ActionEvent e)
				{
					fCurrentTime.setCurrentTime();
					repaint();
				}
			};

			// set the update period
			if (fContinuousUpdate) {
				new javax.swing.Timer(kContinuousUpdatePeriod,updateClockPanelAction).start();
			}
			else {
				new javax.swing.Timer(kDiscreteUpdatePeriod,updateClockPanelAction).start();
			}
		}

		/******************
		 * PUBLIC METHODS *
		 ******************/

		public void paint(Graphics gr)
		{
			int width = getWidth();
			int height = getHeight();

			gr.setColor(getBackground());
			gr.fillRect(0,0,width,height);

			// show the tickmarks
			fCenterX = width / 2;
			fCenterY = height / 2;

			if (fShowDigitalClock) {
				String digitalTime = "";
				try {
					digitalTime = TimeFormatter.getHMSTimeString(fCurrentTime);
				}
				catch (DateTimeFormatException exc) {
				}
				gr.setColor(Color.black);
				gr.drawString(digitalTime,fCenterX - (gr.getFontMetrics().stringWidth(digitalTime) / 2),
						fCenterY + (height / 5));
			}

			int tickRadius;
			if (width < height) {
				tickRadius = (4 * (width / 2)) / 5;
			}
			else {
				tickRadius = (4 * (height / 2)) / 5;
			}

			int hoursLabel = 3;
			if (fCurrentTime.fHour > 11) {
				hoursLabel = 15;
			}
			int hoursLabelOffset = 16;
			for (int i = 0; i < 60; ++i) {

				double angle = i * ((2.0 * Math.PI) / 60.0);
				int x = fCenterX + ((int) Math.round(tickRadius * Math.cos(angle)));
				int y = fCenterY + ((int) Math.round(tickRadius * Math.sin(angle)));

				if ((i % 5) == 0) {

					// plot an hourly tickmark (dark green)
					Color green = Color.green.darker();

					putPixel(gr,x - 1,y - 1,Color.cyan);
					putPixel(gr,x,y - 1,Color.cyan);
					putPixel(gr,x + 1,y - 1,Color.black);

					putPixel(gr,x - 1,y,Color.cyan);
					putPixel(gr,x,y,green);
					putPixel(gr,x + 1,y,Color.black);

					putPixel(gr,x - 1,y + 1,Color.cyan);
					putPixel(gr,x,y + 1,Color.black);
					putPixel(gr,x + 1,y + 1,Color.black);

					// show the hour's label
					x = fCenterX + ((int) Math.round((tickRadius + hoursLabelOffset) * Math.cos(angle)));
					y = fCenterY + ((int) Math.round((tickRadius + hoursLabelOffset) * Math.sin(angle)));
					y += 5;
					if (hoursLabel >= 10) {
						x -= 5;
					}

					gr.setColor(Color.black);
					if (fUse12HourClockDigits) {
						if (hoursLabel > 12) {
							gr.drawString(String.valueOf(hoursLabel - 12),x,y);
						}
						else {
							gr.drawString(String.valueOf(hoursLabel),x,y);
						}
					}
					else {
						gr.drawString(String.valueOf(hoursLabel),x,y);
					}

					++hoursLabel;
					if ((hoursLabel > 24) && (fCurrentTime.fHour > 11)) {
						hoursLabel = 13;
					}
					else if ((hoursLabel > 12) && (fCurrentTime.fHour < 12)) {
						hoursLabel = 1;
					}
				}
				else {
					// a minute/second tickmark
					putPixel(gr,x - 1,y - 1,Color.gray);
					putPixel(gr,x,y - 1,Color.gray);

					putPixel(gr,x - 1,y,Color.gray);
					putPixel(gr,x,y,Color.lightGray);
					putPixel(gr,x + 1,y,Color.white);

					putPixel(gr,x,y + 1,Color.white);
					putPixel(gr,x + 1,y + 1,Color.white);
				}
			}

			int hoursHandRadius = (3 * tickRadius) / 5;
			int minutesHandRadius = (4 * tickRadius) / 5;
			int secondsHandRadius = minutesHandRadius;

			// show the clock's hour hand
			int hours = fCurrentTime.fHour;
			if (hours >= 12) {
				hours -= 12;
			}
			double hoursAngle = hours * ((2.0 * Math.PI) / 12.0) - (Math.PI / 2.0);
			hoursAngle += (((double) fCurrentTime.fMinute / 60.0) * ((2.0 * Math.PI) / 12.0));
			int hoursX = fCenterX + ((int) Math.round(hoursHandRadius * Math.cos(hoursAngle)));
			int hoursY = fCenterY + ((int) Math.round(hoursHandRadius * Math.sin(hoursAngle)));
			gr.setColor(Color.black);
			gr.drawLine(fCenterX,fCenterY,hoursX,hoursY);
			gr.drawLine(fCenterX - 1,fCenterY,hoursX,hoursY);
			gr.drawLine(fCenterX + 1,fCenterY,hoursX,hoursY);
			gr.drawLine(fCenterX,fCenterY - 1,hoursX,hoursY);
			gr.drawLine(fCenterX,fCenterY + 1,hoursX,hoursY);

			// show the clock's minute hand
			double minutesAngle = fCurrentTime.fMinute * ((2.0 * Math.PI) / 60.0) - (Math.PI / 2.0);
			if (fContinuousUpdate) {
				minutesAngle += (((double) fCurrentTime.fSecond / 60.0) * ((2.0 * Math.PI) / 60.0));
			}
			int minutesX = fCenterX + ((int) Math.round(minutesHandRadius * Math.cos(minutesAngle)));
			int minutesY = fCenterY + ((int) Math.round(minutesHandRadius * Math.sin(minutesAngle)));
			gr.setColor(Color.black);
			gr.drawLine(fCenterX,fCenterY,minutesX,minutesY);
			gr.drawLine(fCenterX - 1,fCenterY,minutesX,minutesY);
			gr.drawLine(fCenterX + 1,fCenterY,minutesX,minutesY);
			gr.drawLine(fCenterX,fCenterY - 1,minutesX,minutesY);
			gr.drawLine(fCenterX,fCenterY + 1,minutesX,minutesY);

			/*
			 if (ftimeChooserType != kHourMinuteType) {
			 ...
			 }
			 */

			// show the clock's second hand
			fSecondsRadiusZone = secondsHandRadius;
			double secondsAngle = fCurrentTime.fSecond * ((2.0 * Math.PI) / 60.0) - (Math.PI / 2.0);
			if (fContinuousUpdate) {
				secondsAngle += (((double) fCurrentTime.fMillisecond / 1000.0) * ((2.0 * Math.PI) / 60.0));
			}
			int secondsX = fCenterX + ((int) Math.round(secondsHandRadius * Math.cos(secondsAngle)));
			int secondsY = fCenterY + ((int) Math.round(secondsHandRadius * Math.sin(secondsAngle)));
			gr.setColor(Color.red);
			gr.drawLine(fCenterX,fCenterY,secondsX,secondsY);

			// show a small circle in the middle
			gr.setColor(Color.blue);
			gr.fillOval(fCenterX - 3,fCenterY - 3,7,7);
		}

		public void putPixel(Graphics gr, int x, int y, Color color)
		{
			gr.setColor(color);
			gr.drawLine(x,y,x,y);
		}

		// the mouse-listener
		public final void mouseClicked(MouseEvent e)
		{
			int x = e.getX() - fCenterX;
			int y = e.getY() - fCenterY;
			int radius = (int) Math.round(Math.sqrt((x * x) + (y * y)));

			if ((radius > 20) && (radius <= fSecondsRadiusZone)) {

				int seconds = 60 - ((int) Math.floor(60.0 * (MathTools.atan(x,y) / (2.0 * Math.PI)))) + 15;
				if (seconds > 60) {
					seconds = seconds - 61;
				}
				seconds = MathTools.clip(seconds,0,59);
				fTime.fSecond = seconds;
				fcbSecond.setSelectedIndex(fTime.fSecond);
				repaint();
			}
		}

		public final void mouseEntered(MouseEvent e)
		{
		}

		public final void mouseExited(MouseEvent e)
		{
		}

		public final void mousePressed(MouseEvent e)
		{
		}

		public final void mouseReleased(MouseEvent e)
		{
		}

		// the mouse-motion-listener
		public final void mouseDragged(MouseEvent e)
		{
			mouseClicked(e);
		}

		public final void mouseMoved(MouseEvent e)
		{
		}
	}
}
