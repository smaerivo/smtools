// --------------------------------------------
// Filename      : JStandardGUIApplication.java
// Author        : Sven Maerivoet
// Last modified : 16/08/2007
// Target        : Java VM (1.6)
// --------------------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.application;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import org.apache.log4j.*;
import smtools.application.registry.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.miscellaneous.*;
import smtools.swing.dialogs.*;
import smtools.swing.util.*;

/**
 * The <CODE>JStandardGUIApplication</CODE> class provides a standard Swing based GUI framework.
 * <P>
 * By default, the <CODE>JStandardGUIApplication</CODE> class will result in the following GUI:
 * <P>
 * <UL>
 *   <IMG src="doc-files/standard-gui.png">
 * </UL>
 * <P>
 * Typically, this <CODE>JStandardGUIApplication</CODE> is subclassed, with several methods overridden.
 * These methods control the application's settings, the visual layout of its GUI, and the actions that need to be
 * taken upon user input. 
 * <P>
 * The overridable methods that define the GUI's form and behavior are:
 * <P>
 * <UL>
 *   <LI><B><U>Java runtime environment version checking</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#getRequiredMajorJavaVersion()}</LI>
 *     <LI>{@link JStandardGUIApplication#getRequiredMinorJavaVersion()}</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Command-line parameter parsing</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#parseParameter(int,String)}</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Location of application resources</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#getApplicationResourcesPath()}</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Splash screen during startup</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#getCustomSplashScreenContent()}</LI>
 *     <LI>{@link JStandardGUIApplication#getSplashScreenSoundFilename()} [<I>see also {@link JSplashScreen}</I>]</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Custom initialisation</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#initializeClass(Object[])}</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Visual layout (window related)</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#getInitialLookAndFeel()}</LI>
 *     <LI>{@link JStandardGUIApplication#getInitialGUISize()}</LI>
 *     <LI>{@link JStandardGUIApplication#isGUIResizable()}</LI>
 *     <LI>{@link JStandardGUIApplication#getIconFilename()}</LI>
 *     <LI>{@link JStandardGUIApplication#getWindowTitle()}</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Visual layout (content related)</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#constructContentPane(JPanel)}</LI>
 *     <LI>{@link JStandardGUIApplication#constructMenus()}</LI>
 *     <LI>{@link JStandardGUIApplication#constructRightHandMenu()}</LI>
 *     <LI>{@link JStandardGUIApplication#isClockShownInMenuBar()}</LI>
 *     <LI>{@link JStandardGUIApplication#getAboutBox()} [<I>see also {@link JAboutBox}</I>]</LI>
 *   </UL>
 *   <P>
 *   <LI><B><U>Reacting to user input</U></B></LI>
 *   <P>
 *   <UL>
 *     <LI>{@link JStandardGUIApplication#actionPerformed(ActionEvent)}</LI>
 *   </UL>
 * </UL>
 * <P>
 * Note that by default, a "<I>General</I>" menu is present, which looks as follows:
 * <P>
 * <UL>
 *   <IMG src="doc-files/standard-menu.png">
 * </UL>
 * <P>
 * Note that if the underlying operating system allows for minimisation to the system tray,
 * then this options becomes available in the menu.
 * <P>
 * As the application is ran, the global {@link Registry} is read from file (and stored back
 * to file at the end).
 * <P>
 * When the user wants to quit the program, a confirmation dialog is shown:
 * <P>
 * <UL>
 *   <IMG src="doc-files/quit-dialog.png">
 * </UL>
 * <P>
 * Note that this confirmation can be skipped if {@link JDevelopMode#fModeActivated} is
 * set to <CODE>true</CODE>.
 * 
 * @author  Sven Maerivoet
 * @version 16/08/2007
 * @see     JDerivedGUIApplication
 */
public class JStandardGUIApplication extends JFrame implements ActionListener, WindowListener
{
	// the different window-sizes
	/**
	 * Useful constant to specify that the GUI should fit exactly around its components.
	 */
	protected static final int kAutoSizeGUI = -1;

	/**
	 * Useful constant to specify that the GUI should have full screen size.
	 * <P>
	 * Note that the <B>maximised state</B> of a window is currently not yet supported due to Java lack thereof.
	 */
	protected static final int kFullScreenGUI = 0;

	// the different look-and-feels
	/**
	 * Useful constant for specifying Java's Metal look-and-feel.
	 */
	protected static final String klafMetal = "javax.swing.plaf.metal.MetalLookAndFeel";

	/**
	 * Useful constant for specifying the Motif look-and-feel.
	 */
	protected static final String klafMotif = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";

	/**
	 * Useful constant for specifying the Microsoft Windows look-and-feel.
	 */
	protected static final String klafWindows = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";

	/**
	 * Useful constant for specifying the current platform's look-and-feel.
	 */
	protected static final String klafPlatform = "platform-dependent";

	// access point to the Log4j logging facility
	private static final Logger kLogger = Logger.getLogger(JStandardGUIApplication.class.getName());

	// default window title
	private static final String kDefaultWindowTitle = "smtools.application.JStandardGUIApplication";

	// default application icon filename
	private static final String kDefaultApplicationIconFilename = "smtools-resources/images/icon.jpg";

	// default splash sound filename
	private static final String kDefaultSplashScreenSoundFilename = "smtools-resources/sounds/thx-intro.wav";

	// system registry filename
	private static final String kSystemRegistryFilename = "smtools-resources/registry/registry.ser";

	// the different parameters
	private static final String kParamLanguage = "LANGUAGE";
	private static final String kParamLanguageDutch = "DUTCH";
	private static final String kParamLanguageEnglish = "ENGLISH";
	private static final String kParamLanguageAmerican = "AMERICAN";
	private static final String kParamDevelopMode = "DEVELOPMODE";
	private static final String kParamWidth = "WIDTH";
	private static final String kParamHeight = "HEIGHT";
	private static final String kParamGUIFullScreen = "FULLSCREEN";
	private static final String kParamGUIAutoSize = "AUTOSIZE";
	private static final String kParamHelp = "HELP";

	// the default initial look-and-feel
	private static final String klafInitialLaF = klafPlatform;

	// set the clock's update period to 1 second
	private static final int kClockUpdatePeriod = 1000 * 1;

	// switch for first-time initialisation of the registry
	private static final boolean kSaveSystemRegistry = false;

	// internal datastructures
	protected boolean fGUIResizable;
	private Registry fRegistry;
	private int fGUIWidth;
	private int fGUIHeight;
	private JRadioButtonMenuItem frbMetal;
	private JRadioButtonMenuItem frbWindows;
	private JRadioButtonMenuItem frbMotif;
	private JLabel fClockLabel;
	private String fMessageFilename;
	private JSplashScreen fSplashScreen;
	private JGUIComponentCache fGUIComponentCache;
	private int fAboutBoxID;
	private boolean fMinimiseToSystemTray;
	private TrayIcon fTrayIcon;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JStandardGUIApplication</CODE> object.
	 * <P>
	 * During construction of the GUI, the following events take place:
	 * <P>
	 * <UL>
	 *   <LI><I>The required version of the Java runtime engine is checked </I> (see {@link JStandardGUIApplication#getRequiredMajorJavaVersion()} and
	 *       {@link JStandardGUIApplication#getRequiredMinorJavaVersion()}).</LI>
	 *   <P>
	 *   <LI><I>The GUI is set to auto-size by default</I> (see {@link JStandardGUIApplication#getInitialGUISize()} and
	 *       {@link JStandardGUIApplication#isGUIResizable()}).</LI>
	 *   <P>
	 *   <LI>British English is the default language used.</LI>
	 *   <P>
	 *   <LI><I>The command-line parameters are parsed </I> (see {@link JStandardGUIApplication#parseParameter(int,String)}).</LI>
	 *   <P>
	 *   <LI>The system's {@link Messages} database is loaded.</LI>
	 *   <P>
	 *   <LI>The application's {@link Messages} database is loaded (if it is present).</LI>
	 *   <P>
	 *   <LI>The global {@link Registry} is read from file.</LI>
	 *   <P>
	 *   <LI>The application's {@link Registry} is read from file (if it is present).</LI>
	 *   <P>
	 *   <LI>The GUI's component cache is initialized (see {@link JGUIComponentCache}).</LI>
	 *   <P>
	 *   <LI>The look-and-feel of the operating system is used by default.</LI>
	 *   <P>
	 *   <LI><I>A optional splash screen is shown</I> (see {@link JStandardGUIApplication#getCustomSplashScreenContent()} and
	 *       {@link JStandardGUIApplication#getSplashScreenSoundFilename()}).</LI>
	 *   <P>
	 *   <LI><I>Custom initialisation is performed</I> (see {@link JStandardGUIApplication#initializeClass(Object[])}).</LI>
	 *   <P>
	 *   <LI><I>The window's icon and title are set</I> (see {@link JStandardGUIApplication#getIconFilename()} and
	 *       {@link JStandardGUIApplication#getWindowTitle()}).</LI>
	 *   <P>
	 *   <LI><I>The GUI's content pane is constructed</I> (see {@link JStandardGUIApplication#constructContentPane(JPanel)}).</LI>
	 *   <P>
	 *   <LI><I>The GUI's menu bar is constructed</I> (see {@link JStandardGUIApplication#constructMenus()} and
	 *       {@link JStandardGUIApplication#constructRightHandMenu()}).</LI>
	 *   <P>
	 *   <LI><I>The about box is shown</I> (see {@link JStandardGUIApplication#getAboutBox()}).</LI>
	 * </UL>
	 * <P>
	 * <B>The items in <I>italic</I> can be influenced in a derived subclass.</B>
	 * <P>
	 * If no parameters are to be passed to the GUI, specify <CODE>null</CODE>
	 * for <CODE>parameters</CODE>.
	 *
	 * @param argv       an array of strings containing the <B>command-line</B> parameters
	 * @param parameters an array of objects containing the parameters to be passed to the GUI's
	 *                   {@link JStandardGUIApplication#initializeClass(Object[])} method
	 */
	public JStandardGUIApplication(String[] argv, Object[] parameters)
	{
		kLogger.info("Starting application...");

		// check Java runtime version requirements
		kLogger.info("Checking Java runtime environment requirements...");
		String javaRuntimeVersion = System.getProperty("java.version");
		int dotPosition = javaRuntimeVersion.indexOf(".");
		int javaMajorVersion = (Integer.valueOf(javaRuntimeVersion.substring(dotPosition - 1,dotPosition))).intValue();
		int javaMinorVersion = (Integer.valueOf(javaRuntimeVersion.substring(dotPosition + 1,dotPosition + 2))).intValue();
		String requiredJavaRuntimeVersion = getRequiredMajorJavaVersion() + "." + getRequiredMinorJavaVersion();
		if ((javaMajorVersion < getRequiredMajorJavaVersion()) ||
				((javaMajorVersion >= getRequiredMajorJavaVersion()) && (javaMinorVersion < getRequiredMinorJavaVersion()))) {
			abortApplication("Current version of Java runtime environment (" +
				javaRuntimeVersion +
				") is incompatible with requirements (" +
				requiredJavaRuntimeVersion +
				").",false);
		}

		fGUIWidth = kAutoSizeGUI;
		fGUIHeight = kAutoSizeGUI;

		Dimension initialGUISize = getInitialGUISize();
		if (initialGUISize != null) {
			fGUIWidth = initialGUISize.width;
			fGUIHeight = initialGUISize.height;
		}

		fMessageFilename = Messages.kFilenameLanguageEnglish;

		parseCommandLine(argv);

		// load the system's dictionary database
		kLogger.info("Loading system dictionary database...");
		try {
			Messages.load(fMessageFilename);
		}
		catch (FileDoesNotExistException exc) {
			abortApplication("Language definition file [" + exc.getFilename() + "] not found.",false);
		}

		// load the application's dictionary database
		if (getApplicationResourcesPath() != null) {
			kLogger.info("Loading application dictionary database...");
			try {
				Messages.load(getApplicationResourcesPath() + "languages/" + fMessageFilename.substring(fMessageFilename.lastIndexOf('/') + 1));
			}
			catch (FileDoesNotExistException exc) {
				abortApplication("Language definition file [" + exc.getFilename() + "] not found.",false);
			}
		}

		// obtain a reference to the registry
		fRegistry = Registry.getInstance();

		// load (deserialise) the registry
		kLogger.info("Loading system registry hives...");
		try {
			fRegistry.load(kSystemRegistryFilename);
		}
		catch (RegistryException exc) {
			abortApplication(exc.getRegistryError(),true);
		}

		// load the application's registry
		if (getApplicationResourcesPath() != null) {
			String applicationRegistryFilename = getApplicationResourcesPath() + "registry/registry.ser";

			File file = new File(applicationRegistryFilename);
			if (file.exists()) {
				try {
					kLogger.info("Loading application registry hives...");

					// automatically join both system and application registries
					fRegistry.load(applicationRegistryFilename);
				}
				catch (RegistryException exc) {
					abortApplication(exc.getRegistryError(),true);
				}
			}
		}

		// initialize GUI component cache
		kLogger.info("Initialising GUI component cache...");
		fGUIComponentCache = new JGUIComponentCache();

		// make the contents of windows dynamic (e.g., resizing background images, ...)
		Toolkit.getDefaultToolkit().setDynamicLayout(true);

		// set the look-and-feel to that of the platform
		kLogger.info("Setting GUI look and feel...");
		setInitialLookAndFeel(getInitialLookAndFeel());

		fSplashScreen = new JSplashScreen(getCustomSplashScreenContent(),getSplashScreenSoundFilename());

		// change the cursor to indicate that the user has to wait
		setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));

		setTitle(kDefaultWindowTitle);

		// allow custom initialisation
		kLogger.info("Performing custom initialisation...");
		initializeClass(parameters);
		getSplashScreen().setStatusMessage(Messages.lookup("textCachingAboutBox",null));

		kLogger.info("Creating GUI components...");

		// add about box to the GUI component cache
		JDefaultDialog aboutBox = getAboutBox();
		fAboutBoxID = fGUIComponentCache.addComponent(aboutBox);

		getSplashScreen().setStatusMessage(Messages.lookup("textConstructingGUI",null));

		// load the application's icon
		ImageIcon iconImage = JImageLoader.loadImageIconWithWarning(getIconFilename(),this,
				"errorIconImageNotFound");
		if (iconImage != null) {
			setIconImage(iconImage.getImage());
		}

		setTitle(getWindowTitle());
		setResizable(isGUIResizable());

		// setup content pane
 		JPanel contentPane = new JPanel();
		constructContentPane(contentPane);
		setContentPane(contentPane);

		// if necessary, add the clock
		if (isClockShownInMenuBar()) {

			fClockLabel = new JLabel("",SwingConstants.RIGHT);

			// create a Swing timer to periodically update the clock label
			Action updateClockPanelAction = new AbstractAction()
			{
				public void actionPerformed(ActionEvent e)
				{
					updateCurrentTimeLabel();
				}
			};

			// set the update period to 5 seconds
			new javax.swing.Timer(kClockUpdatePeriod,updateClockPanelAction).start();

			// perform the first update when the GUI is displayed
			updateCurrentTimeLabel();
		}

		// setup menu bar
		JMenuBar menuBar = new JMenuBar();
		constructMenuBar(menuBar);
		setJMenuBar(menuBar);

		// we will handle the window-actions ourselves
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(this);

		pack();

		// determine the GUI's maximum screensize
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		if (fGUIWidth == kFullScreenGUI) {
			fGUIWidth = (int) Math.round(screenSize.getWidth());
		}
		if (fGUIHeight == kFullScreenGUI) {
			fGUIHeight = (int) Math.round(screenSize.getHeight());
		}

		// determine the requested GUI's screensize
		if (fGUIWidth == kAutoSizeGUI) {
			// fit tightly around all the components' natural widths
			fGUIWidth = getSize().width;
		}
		if (fGUIHeight == kAutoSizeGUI) {
			// fit tightly around all the components' natural heights
			fGUIHeight = getSize().height;
		}

		setSize(new Dimension(fGUIWidth,fGUIHeight));

		if (fSplashScreen.isAvailable()) {
			fSplashScreen.setVisible(false);
			fSplashScreen.dispose();
		}

		setVisible(true);

		// restore the cursor
		setCursor(Cursor.getDefaultCursor());

		// update the menu's radio buttons
		setLookAndFeel(getInitialLookAndFeel());

		// check whether or not minimising to the system tray is supported
		fMinimiseToSystemTray = SystemTray.isSupported();

		// show the aboutbox
		aboutBox = (JDefaultDialog) fGUIComponentCache.retrieveComponent(fAboutBoxID);

		kLogger.info("Application ready.");

		if ((!JDevelopMode.fModeActivated) && (aboutBox != null)) {
			aboutBox.activate();
		}
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	// the action-listener
	/**
	 * The GUI's <B>action listener</B>.
	 * <P>
	 * Note that when overriding this method in a subclass, its parent should
	 * explicitly be called in order to guarantee the correct default processing of
	 * the user's input:
	 * <P>
	 * <CODE>
	 * <PRE>
	 *   super.actionPerformed(e);
	 *   // rest of method's code
	 * </PRE>
	 * </CODE>
	 *
	 * @param e the <CODE>ActionEvent</CODE> that is received
	 */
	public void actionPerformed(ActionEvent e)
	{
		String command = e.getActionCommand();

		if (command.equalsIgnoreCase(Messages.lookup("menuItemAbout",null))) {

			JDefaultDialog aboutBox = (JDefaultDialog) fGUIComponentCache.retrieveComponent(fAboutBoxID);

			if (aboutBox != null) {
				aboutBox.activate();
			}
		}
		else if (command.equalsIgnoreCase(klafMetal)) {
			setLookAndFeel(klafMetal);
		}
		else if (command.equalsIgnoreCase(klafMotif)) {
			setLookAndFeel(klafMotif);
		}
		else if (command.equalsIgnoreCase(klafWindows)) {
			setLookAndFeel(klafWindows);
		}
		else if (command.equalsIgnoreCase(klafPlatform)) {
			setLookAndFeel(klafPlatform);
		}
		else if (command.equalsIgnoreCase(Messages.lookup("menuItemMinimiseToSystemTray",null))) {
			fMinimiseToSystemTray = !fMinimiseToSystemTray; 
		}
		else if (command.equalsIgnoreCase(Messages.lookup("menuItemQuit",null))) {
			windowClosing(null);
		}
	}

	// the window-listener
	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowActivated(WindowEvent e)
	{
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowClosed(WindowEvent e)
	{
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowClosing(WindowEvent e)
	{
		if (!JDevelopMode.fModeActivated) {

			if (JConfirmationDialog.confirm(this,Messages.lookup("textConfirmExitProgram",null))) {

				kLogger.info("Saving registry hives...");
				saveRegistry();

				// quit the running program
				kLogger.info("Application terminated.");
				System.exit(0);
			}
		}
		else {
			kLogger.info("Saving registry hives...");
			saveRegistry();

			// quit the running program
			kLogger.info("Application terminated.");
			System.exit(0);
		}
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowDeactivated(WindowEvent e)
	{
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowDeiconified(WindowEvent e)
	{
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowIconified(WindowEvent e)
	{
		if (fMinimiseToSystemTray) {
			Image image = Toolkit.getDefaultToolkit().getImage("smtools-resources/images/icon.jpg");
			fTrayIcon = new TrayIcon(image,getWindowTitle(),null);
			fTrayIcon.setImageAutoSize(true);

			MouseListener iconListener = new MouseListener() {
				public void mouseClicked(MouseEvent e) {
					setVisible(true);
					SystemTray.getSystemTray().remove(fTrayIcon);
				}
				public void mouseEntered(MouseEvent e) { }
				public void mouseExited(MouseEvent e) { }
				public void mousePressed(MouseEvent e) { }
				public void mouseReleased(MouseEvent e) { }
			};
			fTrayIcon.addMouseListener(iconListener);

			try {
				SystemTray.getSystemTray().add(fTrayIcon);
				fTrayIcon.displayMessage(getWindowTitle(), 
						Messages.lookup("textRestoreFromSystemTray",null),
						TrayIcon.MessageType.INFO);
				setVisible(false);
			}
			catch (AWTException exc) {
				kLogger.error(Messages.lookup("errorMinimisingToSystemTray",null));
			}
		}
	}

	/**
	 * A method from the dialog box's <B>window listener</B>.
	 * <P>
	 * Note that this method cannot be overridden !
	 *
	 * @param e the <CODE>WindowEvent</CODE> that is received
	 */
	public final void windowOpened(WindowEvent e)
	{
	}

	/**
	 * The program's <CODE>main</CODE> method.
	 * <P>
	 * Note that this method should be overridden by a derived subclass:
	 * <P>
	 * <CODE>
	 * <PRE>
	 *   public static void main(String[] argv)
	 *   {
	 *     DerivedGUIApplication derivedGUIApplication = new DerivedGUIApplication(argv);
	 *   }
	 * </PRE>
	 * </CODE>
	 *
	 * @param argv an array of strings containing the <B>command-line</B> parameters
	 */
	public static void main(String[] argv)
	{
		saveSystemRegistry();
		new JStandardGUIApplication(argv,null);
	}

	/*********************
	 * PROTECTED METHODS *
	 *********************/

	/**
	 * Returns the required major version of the Java runtime engine that wants to run this application (e.g., 1 for JRE 1.6.0).
	 *
	 * @return the required major version of the Java runtime engine
	 */
	protected int getRequiredMajorJavaVersion()
	{
		return 1;
	}

	/**
	 * Returns the required minor version of the Java runtime engine that wants to run this application (e.g., 6 for JRE 1.6.0).
	 *
	 * @return the required minor version of the Java runtime engine
	 */
	protected int getRequiredMinorJavaVersion()
	{
		return 6;
	}

	/**
	 * Returns the path to the application's resources.
	 * <P>
	 * Note that the path should be terminated with a slash (/).
	 *
	 * @return the path to the application's resources
	 */
	protected String getApplicationResourcesPath()
	{
		return null;
	}

	/**
	 * Returns the application's initial look-and-feel.
	 * <P>
	 * The possible values that can be returned are:<BR>
	 * <BR>
	 * <UL>
	 *   <LI>Java's Metal look-and-feel ({@link JStandardGUIApplication#klafMetal})</LI>
	 *   <LI>the Motif look-and-feel ({@link JStandardGUIApplication#klafMotif})</LI>
	 *   <LI>the Microsoft Windows look-and-feel ({@link JStandardGUIApplication#klafWindows})</LI>
	 *   <LI>the current platform's look-and-feel ({@link JStandardGUIApplication#klafPlatform})</LI>
	 * </UL>
	 * <P>
	 * Note that this method returns the current platform's look-and-feel by default.
	 * 
	 * @return the application's initial look-and-feel
	 */
	protected String getInitialLookAndFeel()
	{
		return klafInitialLaF;
	}

	/**
	 * Returns the GUI's initial size on the screen.
	 * <P>
	 * A derived subclass should return a <CODE>Dimension</CODE> object containing the initial
	 * width and height of the GUI's window. Their values are expressed in pixels, but the following
	 * two special values are also accepted:
	 * <P>
	 * <UL>
	 *   <LI>{@link JStandardGUIApplication#kAutoSizeGUI}</LI>
	 *   <LI>{@link JStandardGUIApplication#kFullScreenGUI}</LI>
	 * </UL>
	 * <P>
	 * An example:
	 * <P>
	 * <UL>
	 *   <CODE>return (new Dimension(JStandardGUIApplication.kFullScreenGUI,250));</CODE>
	 * </UL>
	 * <P>
	 * which specifies a GUI with full screen width and 250 pixels height.
	 *
	 * @return the GUI's initial size on the screen as a <CODE>Dimension</CODE> object
	 */
	protected Dimension getInitialGUISize()
	{
		return null;
	}

	/**
	 * Returns whether or not the GUI's window should be resizable.
	 * <P>
	 * This method returns <CODE>true</CODE> by default.
	 *
	 * @return <CODE>true</CODE> if the GUI's window should be resizable, <CODE>false</CODE> if it should be fixed size.
	 */
	protected boolean isGUIResizable()
	{
		return true;
	}

	/**
	 * Returns the name of the file containing the GUI's icon image.
	 * <P>
	 * The icon image should be a JPG-file, 32x32 pixels with 24-bit colourdepth (i.e., true colour).
	 *
	 * @return the name of the file containing the GUI's icon image
	 */
	protected String getIconFilename()
	{
		return kDefaultApplicationIconFilename;
	}

	/**
	 * Returns the GUI's window title.
	 *
	 * @return the GUI's window title
	 */
	protected String getWindowTitle()
	{
		return kDefaultWindowTitle;
	}

	/**
	 * Returns a <CODE>JLabel</CODE> containing the splash screen's custom content.
	 * <P>
	 * See {@link JSplashScreen} for more information regarding the splash screen.
	 *
	 * @return a <CODE>JLabel</CODE> containing the splash screen's custom content
	 * @see    JSplashScreen
	 */
	protected JLabel getCustomSplashScreenContent()
	{
		return null;
	}

	/**
	 * Returns the name of the file containing the sound to play during the splash screen.
	 * <P>
	 * See {@link JSplashScreen} for more information regarding the splash screen.
	 *
	 * @return the name of the file containing the sound to play during the splash screen
	 * @see    JSoundClip
	 * @see    JSoundStream
	 * @see    JSplashScreen
	 */
	protected String getSplashScreenSoundFilename()
	{
		return kDefaultSplashScreenSoundFilename;
	}

	/**
	 * Returns a handle to the GUI's splash screen.
	 *
	 * @return a handle to the GUI's splash screen
	 * @see    JSplashScreen
	 */
	protected final JSplashScreen getSplashScreen()
	{
		return fSplashScreen;
	}

	/**
	 * Returns an object containing a custom about box.
	 * <P>
	 * Note that this method returns <CODE>null</CODE> by default, indicating that no
	 * about box is available.
	 *
	 * @return the about box dialog
	 * @see    JAboutBox
	 */
	protected JAboutBox getAboutBox()
	{
		return null;
	}

	/**
	 * Returns a handle to the GUI's internal component cache.
	 *
	 * @return a handle to the GUI's internal component cache
	 * @see    JGUIComponentCache
	 */
	protected final JGUIComponentCache getGUIComponentCache()
	{
		return fGUIComponentCache;
	}

	/**
	 * Allows custom initialisation of the subclass's member fields.
	 * <P>
	 * The parameters in the <CODE>Object[]</CODE> array are passed through
	 * the class's constructor (see {@link JStandardGUIApplication#JStandardGUIApplication(String[],Object[])}).
	 *
	 * @param parameters an array of <CODE>Objects</CODE>
	 */
	protected void initializeClass(Object[] parameters)
	{
	}

	/**
	 * Allows construction of the GUI's content pane.
	 * <P>
	 * A derived subclass typically overrides this method. The subclass can
	 * operate on the given <CODE>contentPane</CODE> parameter (which is initialized,
	 * i.e., not <CODE>null</CODE>, by default).
	 * <P>
	 * A subclass thus sets the content pane's layout managers, adds components to it, ...
	 *
	 * @param contentPane the GUI's main content pane to modify
	 */
	protected void constructContentPane(JPanel contentPane)
	{
	}

	/**
	 * Allows the construction of custom menus.
	 * <P>
	 * By default, the application already contains a "<I>General</I>" menu containing
	 * access to the optional about box, setting the GUI's look and feel and getting confirmation
	 * when the user wants to quit the program.
	 * <P>
	 * Note that this method returns <CODE>null</CODE> by default.
	 *
	 * @return an array of menus
	 * @see    JStandardGUIApplication#constructRightHandMenu()
	 */
	protected JMenu[] constructMenus()
	{
		return null;
	}

	/**
	 * Allows the construction of a custom right hand menu (e.g., a "<I>Help</I>" menu).
	 * <P>
	 * Note that this method returns <CODE>null</CODE> by default.
	 *
	 * @return a menu used in the right part of the menubar
	 * @see    JStandardGUIApplication#constructMenus()
	 */
	protected JMenu constructRightHandMenu()
	{
		return null;
	}

	/**
	 * Returns whether or not a clock (HH:MM:SS) should be shown at the right of the menubar.
	 * <P>
	 * Note that this method returns <CODE>true</CODE> by default.
	 *
	 * @return whether or not a clock (HH:MM:SS) should be shown at the right of the menubar
	 */
	protected boolean isClockShownInMenuBar()
	{
		return true;
	}
	
	/**
	 * Allows parsing of custom command-line parameters.
	 * <P>
	 * A derived subclass typically overrides this method to parse all its custom command-line parameters.
	 * <P>
	 * Note that if an error occurs during parsing, the {@link JStandardGUIApplication#showParameterWarning(int,String,String)}
	 * method should be called with the appropriate parameters.
	 * <P>
	 * The following example shows the parsing of one custom parameter (with a custom option):
	 * <CODE>
	 * <PRE>
	 *   final String kCustomParameter = "PARAMETER";
	 *   final String kCustomOption    = "OPTION";
	 *
	 *   String upperCaseParameter = parameter.toUpperCase();
	 *
	 *   // parse parameter
	 *   if (upperCaseParameter.startsWith(kCustomParameter &#43; "=")) {
	 *
	 *     String upperCaseOption = upperCaseParameter.substring(kCustomParameter.length() &#43; 1);
	 *     // parse option
	 *     if (upperCaseOption.equalsIgnoreCase(kCustomOption)) {
	 *       // take action as parameter is parsed
	 *     }
	 *     else {
	 *       showParameterWarning(paramNr,parameter,"not a valid option");
	 *     }
	 *
	 *     // indicate that parameter was valid
	 *     return true;
	 *   }
	 *   else {
	 *
	 *     // indicate that parameter is unknown
	 *     return false;
	 *   }
	 * </PRE>
	 * </CODE>
	 *
	 * @param  paramNr   the number of the parameter that is being parsed
	 * @param  parameter the unmodified parameter as specified on the command-line
	 * @return           <CODE>true</CODE> if the parameter was parsed successfully, <CODE>false</CODE> otherwise
	 * @see    JStandardGUIApplication#showParameterWarning(int,String,String)
	 */
	protected boolean parseParameter(int paramNr, String parameter)
	{
		return false;
	}

	/**
	 * Logs a textual warning message.
	 *
	 * @param paramNr   the number of the parameter that failed to get parsed
	 * @param parameter the unmodified parameter as specified on the command-line
	 * @param message   the warning message to log
	 * @see   JStandardGUIApplication#parseParameter(int,String)
	 */
	protected final void showParameterWarning(int paramNr, String parameter, String message)
	{
		kLogger.warn(
			"Warning: parameter #" + String.valueOf(paramNr) + " [" + parameter + "] ignored.\n" +
			"\t => " + message + ".");
	}

	/*******************
	 * PRIVATE METHODS *
	 *******************/

	private void setLookAndFeel(String lookAndFeel)
	{
		lookAndFeel = translateLookAndFeelName(lookAndFeel);

		frbMetal.setSelected(false);
		frbWindows.setSelected(false);
		frbMotif.setSelected(false);

		if (lookAndFeel.equalsIgnoreCase(klafMetal)) {
			frbMetal.setSelected(true);
		}
		else if (lookAndFeel.equalsIgnoreCase(klafWindows)) {
			frbWindows.setSelected(true);
		}
		else if (lookAndFeel.equalsIgnoreCase(klafMotif)) {
			frbMotif.setSelected(true);
		}

		// change the look-and-feel
		try {
			UIManager.setLookAndFeel(lookAndFeel);
			SwingUtilities.updateComponentTreeUI(this);
			fGUIComponentCache.updateComponentTreeUI();
			repaint();
		}
		catch (Exception exc) {
		}
	}

	private void setInitialLookAndFeel(String lookAndFeel)
	{
		try {
			UIManager.setLookAndFeel(translateLookAndFeelName(lookAndFeel));
		}
		catch (Exception exc) {
		}
	}

	private String translateLookAndFeelName(String lookAndFeel)
	{
		// if no look-and-feel was specified then the platform's look-and-feel is used
		if (lookAndFeel.equalsIgnoreCase(klafPlatform)) {
			return UIManager.getSystemLookAndFeelClassName();
		}
		else {
			return lookAndFeel;
		}
	}

	private void constructMenuBar(JMenuBar menuBar)
	{
		JMenu menu = null;
		JMenu subMenu = null;
		JMenuItem menuItem = null;
		ButtonGroup buttonGroup = null;

		// the general menu
		menu = new JMenu(Messages.lookup("menuGeneral",null));
		menu.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuMnemonicGeneral",null)));
		menuBar.add(menu);

		JDefaultDialog aboutBox = (JDefaultDialog) fGUIComponentCache.retrieveComponent(fAboutBoxID);
		if (aboutBox != null) {

			menuItem = new JMenuItem(Messages.lookup("menuItemAbout",null),Messages
					.translateMnemonic(Messages.lookup("menuItemMnemonicAbout",null)));
			menuItem.addActionListener(this);
			menu.add(menuItem);
		}

		// the look-and-feel submenu
		subMenu = new JMenu(Messages.lookup("menuLookAndFeel",null));
		subMenu
				.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuMnemonicLookAndFeel",null)));

		buttonGroup = new ButtonGroup();
		frbMetal = new JRadioButtonMenuItem(Messages.lookup("menuItemMetalLAF",null));
		frbMetal.setMnemonic(Messages.translateMnemonic(Messages
				.lookup("menuItemMnemonicMetalLAF",null)));
		frbMetal.setSelected(false);
		frbMetal.addActionListener(this);
		frbMetal.setActionCommand(klafMetal);
		buttonGroup.add(frbMetal);
		subMenu.add(frbMetal);

		frbMotif = new JRadioButtonMenuItem(Messages.lookup("menuItemMotifLAF",null));
		frbMotif.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuItemMnemonicMotifLAF",null)));
		frbMotif.setSelected(false);
		frbMotif.addActionListener(this);
		frbMotif.setActionCommand(klafMotif);
		buttonGroup.add(frbMotif);
		subMenu.add(frbMotif);

		frbWindows = new JRadioButtonMenuItem(Messages.lookup("menuItemWindowsLAF",null));
		frbWindows.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuItemMnemonicWindowsLAF",null)));
		frbWindows.setSelected(false);
		frbWindows.addActionListener(this);
		frbWindows.setActionCommand(klafWindows);
		buttonGroup.add(frbWindows);
		subMenu.add(frbWindows);

		subMenu.addSeparator();

		menuItem = new JMenuItem(Messages.lookup("menuItemSystemLAF",null),Messages.translateMnemonic(Messages.lookup("menuItemMnemonicSystemLAF",null)));
		menuItem.addActionListener(this);
		menuItem.setActionCommand(klafPlatform);
		subMenu.add(menuItem);

		if (SystemTray.isSupported()) {
			subMenu.addSeparator();

			JCheckBoxMenuItem checkboxMenuItem = new JCheckBoxMenuItem(Messages.lookup("menuItemMinimiseToSystemTray",null));
			checkboxMenuItem.setState(true);
			checkboxMenuItem.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuItemMnemonicMinimiseToSystemTray",null)));
			checkboxMenuItem.addActionListener(this);
			subMenu.add(checkboxMenuItem);
		}

		menu.add(subMenu);

		menu.addSeparator();

		menuItem = new JMenuItem(Messages.lookup("menuItemQuit",null),Messages.translateMnemonic(Messages.lookup("menuItemMnemonicQuit",null)));
		menuItem.addActionListener(this);
		menu.add(menuItem);

		// if necessary, add other menus
		JMenu[] otherMenus = constructMenus();
		if (otherMenus != null) {
			for (int menuNr = 0; menuNr < otherMenus.length; ++menuNr) {
				menuBar.add(otherMenus[menuNr]);
			}
		}

		// if necessary, add right hand menu
		boolean menuBarGlued = false;
		JMenu rightHandMenu = constructRightHandMenu();
		if (rightHandMenu != null) {
			menuBar.add(Box.createHorizontalGlue());
			menuBarGlued = true;
			menuBar.add(rightHandMenu);
		}

		// if necessary, add the clock
		if (isClockShownInMenuBar()) {
			if (!menuBarGlued) {
				menuBar.add(Box.createHorizontalGlue());
			}
			menuBar.add(fClockLabel);
		}
	}

	private void updateCurrentTimeLabel()
	{
		Time currentTime = new Time();
		currentTime.setCurrentTime();
		String currenTimeString = "";
		try {
			currenTimeString = " [ " + TimeFormatter.getHMSTimeString(currentTime) + " ] ";
		}
		catch (DateTimeFormatException exc) {
		}
		fClockLabel.setText(currenTimeString);
	}

	private void parseCommandLine(String[] argv)
	{
		if (argv.length > 0) {

			// parse parameters
			for (int paramNr = 1; paramNr <= argv.length; ++paramNr) {

				String parameter = argv[paramNr - 1];
				if (!parameter.startsWith("-")) {
					showParameterWarning(paramNr,parameter,"it doesn't start with a hyphen");
				}
				else {

					// remove the leading hypen and convert to upper case
					parameter = parameter.substring(1);
					String upperCaseParameter = parameter.toUpperCase();

					// parse parameters
					if (upperCaseParameter.startsWith(kParamLanguage + "=")) {

						String option = upperCaseParameter.substring(kParamLanguage.length() + 1);
						if (option.equalsIgnoreCase(kParamLanguageDutch)) {
							fMessageFilename = Messages.kFilenameLanguageDutch;
						}
						else if (option.equalsIgnoreCase(kParamLanguageEnglish)) {
							fMessageFilename = Messages.kFilenameLanguageEnglish;
						}
						else if (option.equalsIgnoreCase(kParamLanguageAmerican)) {
							fMessageFilename = Messages.kFilenameLanguageAmerican;
						}
						else {
							showParameterWarning(paramNr,parameter,"incorrect language specified");
							abortApplication(null,false);
						}
					}
					else if (upperCaseParameter.equalsIgnoreCase(kParamDevelopMode)) {
						JDevelopMode.fModeActivated = true;
					}
					else if (upperCaseParameter.startsWith(kParamWidth + "=")) {

						// note that this parameter overrides the settings in the (derived) class
						String option = upperCaseParameter.substring(kParamWidth.length() + 1);
						if (option.equalsIgnoreCase(kParamGUIFullScreen)) {
							fGUIWidth = kFullScreenGUI;
						}
						else if (option.equalsIgnoreCase(kParamGUIAutoSize)) {
							fGUIWidth = kAutoSizeGUI;
						}
						else {
							try {
								fGUIWidth = (new Integer(option)).intValue();
							}
							catch (NumberFormatException exc) {
								showParameterWarning(paramNr,parameter,"incorrect width specified");
							}
						}
					}
					else if (upperCaseParameter.startsWith(kParamHeight + "=")) {

						// note that this parameter overrides the settings in the (derived) class
						String option = upperCaseParameter.substring(kParamHeight.length() + 1);
						if (option.equalsIgnoreCase(kParamGUIFullScreen)) {
							fGUIHeight = kFullScreenGUI;
						}
						else if (option.equalsIgnoreCase(kParamGUIAutoSize)) {
							fGUIHeight = kAutoSizeGUI;
						}
						else {
							try {
								fGUIHeight = (new Integer(option)).intValue();
							}
							catch (NumberFormatException exc) {
								showParameterWarning(paramNr,parameter,"incorrect height specified");
							}
						}
					}
					else if (upperCaseParameter.startsWith(kParamHelp)) {
						kLogger.info(
							"Available command-line parameters:\n" +
							"\n" +
							"  -language=lll\n" +
							"  -developmode\n" +
							"  -width=f\n" +
							"  -height=yyy\n" +
							"  -help\n" +
							"\n" +
							"Available options:\n" +
							"\n" +
							"  lll can be either dutch, english, or american (default is english)." +
							"  xxx and yyy can be either autosize, fullscreen, or a number (default is autosize).");
						abortApplication(null,false);
					}
					else if (!parseParameter(paramNr,parameter)) {
						showParameterWarning(paramNr,parameter,"unknown parameter specified");
					}
				}
			}
		}
	}

	private void saveRegistry()
	{
		try {
			fRegistry.save(kSystemRegistryFilename);
		}
		catch (RegistryException exc) {
			JWarningDialog.warn(this,exc.getRegistryError());
		}
	}

	private void abortApplication(String abortMessage, boolean translate)
	{
		if (abortMessage != null) {

			if (translate) {
				kLogger.fatal(abortMessage + "\n" + Messages.lookup("textProgramAborted",null));
			}
			else {
				kLogger.fatal(abortMessage + "\n" + "Program aborted.");
			}
		}

		System.exit(0);
	}

	private static void saveSystemRegistry()
	{
		if (kSaveSystemRegistry) {
			kLogger.info("Saving system registry...");

			try {
				Registry registry = Registry.getInstance();

				SystemHive systemHive = new SystemHive();
				systemHive.fContents = new Hashtable<String,Object>();

				// update contents of the system hive
				// ...

				registry.addHive("SystemHive",systemHive);
				registry.save(kSystemRegistryFilename);
				kLogger.info("Done saving registry.");
			}
			catch (Exception exc) {
				kLogger.fatal(exc);
			}
			System.exit(0);
		}
	}
}
