// ------------------------------
// Filename      : Messages.java
// Author        : Sven Maerivoet
// Last modified : 01/11/2004
// Target        : Java VM (1.6)
// ------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.application.util;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import smtools.exceptions.*;

/**
 * The <CODE>Messages</CODE> class provides a mechanism for implementing a multi-lingual dictionary.
 * <P>
 * The idea behind this class is that, whenever a <CODE>String</CODE> locale is needed, it is replaced
 * by a lookup in the dictionary that gives a translation to the currently selected language.
 * The dictionary is based on <I>keys</I> and <I>values</I>: the keys provide the lookup-mechanism,
 * whereas the values represent the translations.
 * <P>
 * When a programme is starting, the database containing the selected dictionary should be loaded
 * using the static {@link Messages#load(String)} method. Lookups are performed as follows:
 * <P>
 * <UL>
 *   <CODE>String translation = Messages.lookup(key,parameters);</CODE>
 * </UL>
 * <P>
 * Up to nine parameters can be substituted in the translation; the parameters are specified
 * in the keys using <CODE>(^i)</CODE> with <CODE>i</CODE> the number of the parameter; in order to
 * get the caret itself, it should be escaped by writing it twice (^^). The lookup is done using an
 * array of strings:
 * <P>
 * <UL>
 *   <CODE>String[] parameters = {"parameter 1",...,"parameter N"};</CODE>
 * </UL>
 * <P>
 * <B><U>Some examples</U></B>
 * <P>
 * <UL>
 *   <LI>Consider the following dictionary file:</LI>
 *   <P>
 *   <UL>
 *     <CODE>myFirstKey=my first value</CODE><BR>
 *     <CODE>mySecondKey=my ^1 value</CODE>
 *   </UL>
 *   <P>
 *   Then the following lookups result in:
 *   <P>
 *   <UL>
 *     <LI><CODE>Messages.lookup("myFirstKey",null)</CODE> will result in "<CODE>my first value</CODE>".</LI>
 *     <P>
 *     <LI><CODE>Messages.lookup("mySecondKey",new String[] = {"second"})</CODE> will result in "<CODE>my second value</CODE>".</LI>
 *   </UL>
 *   <P>
 *   <LI>A GUI is typically constructed with statements like the following one:</LI>
 *   <P>
 *   <PRE>
 *   JLabel label =
 *     new JLabel(
 *        Messages.lookup("labelKey",new String[] {"parameter 1","parameter 2"}));
 *   </PRE>
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 * 
 * @author  Sven Maerivoet
 * @version 01/11/2004
 */
public final class Messages
{
	// language-related definitions
	/**
	 * Useful constant for specifying a Dutch dictionary file.
	 */
	public static final String kFilenameLanguageDutch = "smtools-resources/languages/language-dutch.data";

	/**
	 * Useful constant for specifying a British English dictionary file.
	 */
	public static final String kFilenameLanguageEnglish = "smtools-resources/languages/language-english.data";

	/**
	 * Useful constant for specifying an American English dictionary file.
	 */
	public static final String kFilenameLanguageAmerican = "smtools-resources/languages/language-american.data";

	// internal datastructures
	private static FileInputStream fMessageFile;
	private static Properties fMessageTable;

	/*************************
	 * STATIC INITIALISATION *
	 *************************/

	// prevent instantiation
	static
	{
		fMessageTable = new Properties();
	}

	/****************
	 * CONSTRUCTORS *
	 ****************/

	// prevent instantiation
	private Messages()
	{
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Loads a dictionary database from a specified file.
	 * <P>
	 * The file should have the following structure: each line should contain at most one
	 * (key,value) pair. They are specified as:
	 * <P>
	 * <UL>
	 *   <CODE>key=value</CODE>
	 * </UL>
	 * <P>
	 * Note that although comments are not supported, blank lines are allowed.
	 * <P>
	 * Furthermore, when loading a dictionary database, all <I>existing</I> keys will be
	 * overwritten with the new values.
	 * 
	 * @param  messageFile               the name of the file containing the dictionary database
	 * @throws FileDoesNotExistException if the file containing the dictionary database could not be opened
	 */
	public static void load(String messageFile) throws FileDoesNotExistException
	{
		try {
			fMessageFile = new FileInputStream(messageFile);
			fMessageTable.load(fMessageFile);
		}
		catch (IOException exc) {
			throw (new FileDoesNotExistException(messageFile));
		}
	}

	/**
	 * Clears the dictionary database.
	 */
	public static void clear()
	{
		fMessageTable.clear();
	}
	
	/**
	 * Looks up a key in the dictionary's database and retrieves its translation.
	 * <P>
	 * Note that when the key is not found, an empty string ("") is returned
	 * (<B>not <CODE>null</CODE></B>). Also note that any redundant specified
	 * parameters are ignored.
	 *
	 * @param  messageKey the key to search for in the dictionary's database
	 * @param  parameters the parameters to substitute in the translated value
	 * @return            the value corresponding to the <CODE>messageKey</CODE>
	 */
	public static String lookup(String messageKey, String[] parameters)
	{
		// retrieve message from message table
		String message = fMessageTable.getProperty(messageKey);

		if (message == null) {
			return "";
		}
		String fParsed = "";

		// parse the message
		for (int i = 0; i < message.length(); ++i) {
			String fToAdd = "";

			// was a parameter specified ?
			if (message.charAt(i) == '^') {

				++i;

				// have we reached the end of the string ?
				if (i < message.length()) {

					// do we need to escape the caret ?
					if (message.charAt(i) == '^') {
						fToAdd = "^";
					}
					else {

						// extract the parameter's number
						try {
							int parameterNr = Integer.parseInt(message.substring(i,i + 1)) - 1;

							// lookup the parameter in the list
							if ((parameters != null) && (parameterNr < parameters.length)) {
								fToAdd = parameters[parameterNr];
							}
						}
						catch (NumberFormatException exc) {
						}
					}
				}
			}
			else {
				// no parameter was specified
				fToAdd = String.valueOf(message.charAt(i));
			}

			fParsed = fParsed.concat(fToAdd);
		}

		return fParsed;
	}

	/**
	 * Looks up a key in the dictionary's database and retrieves its translation, ignoring
	 * any parameters.
	 * <P>
	 * Note that when the key is not found, an empty string ("") is returned
	 * (<B>not <CODE>null</CODE></B>).
	 *
	 * @param  messageKey the key to search for in the dictionary's database
	 * @return            the value corresponding to the <CODE>messageKey</CODE>
	 */
	public static String lookup(String messageKey)
	{
		return lookup(messageKey,null);
	}

	/**
	 * Returns the <CODE>KeyEvent</CODE> code associated with the specified mnemonic.
	 * <P>
	 * A mnemonic consists of a single character; this method does however relaxes this
	 * assumption, as it allows for a complete <CODE>String</CODE> to be specified (only the
	 * first character is considered). So its convenient for the caller to pass a <I>key</I>
	 * as parameter to this method.
	 *
	 * @param  mnemonic the mnemonic to retrieve the <CODE>KeyEvent</CODE> code from
	 * @return          the <CODE>KeyEvent</CODE> code associated with the specified mnemonic
	 */
	public static int translateMnemonic(final String mnemonic)
	{
		char mnemonicChar = (mnemonic.toUpperCase()).charAt(0);

		switch (mnemonicChar) {
			case 'A':
				return KeyEvent.VK_A;
			case 'B':
				return KeyEvent.VK_B;
			case 'C':
				return KeyEvent.VK_C;
			case 'D':
				return KeyEvent.VK_D;
			case 'E':
				return KeyEvent.VK_E;
			case 'F':
				return KeyEvent.VK_F;
			case 'G':
				return KeyEvent.VK_G;
			case 'H':
				return KeyEvent.VK_H;
			case 'I':
				return KeyEvent.VK_I;
			case 'J':
				return KeyEvent.VK_J;
			case 'K':
				return KeyEvent.VK_K;
			case 'L':
				return KeyEvent.VK_L;
			case 'M':
				return KeyEvent.VK_M;
			case 'N':
				return KeyEvent.VK_N;
			case 'O':
				return KeyEvent.VK_O;
			case 'P':
				return KeyEvent.VK_P;
			case 'Q':
				return KeyEvent.VK_Q;
			case 'R':
				return KeyEvent.VK_R;
			case 'S':
				return KeyEvent.VK_S;
			case 'T':
				return KeyEvent.VK_T;
			case 'U':
				return KeyEvent.VK_U;
			case 'V':
				return KeyEvent.VK_V;
			case 'W':
				return KeyEvent.VK_W;
			case 'X':
				return KeyEvent.VK_X;
			case 'Y':
				return KeyEvent.VK_Y;
			case 'Z':
				return KeyEvent.VK_Z;
		}

		return 0;
	}
}
