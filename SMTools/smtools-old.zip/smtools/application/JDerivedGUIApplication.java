// -------------------------------------------
// Filename      : JDerivedGUIApplication.java
// Author        : Sven Maerivoet
// Last modified : 16/08/2007
// Target        : Java VM (1.6)
// -------------------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.application;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import smtools.application.util.*;
import smtools.exceptions.*;
import smtools.miscellaneous.*;
import smtools.swing.dialogs.*;
import smtools.swing.util.*;

/**
 * The <CODE>JDerivedGUIApplication</CODE> class is a demonstration of the <I>SMTools</I> GUI framework.
 * <P>
 * When this class's {@link JDerivedGUIApplication#main(String[])} method is invoked, the resulting
 * GUI looks as follows:
 * <P>
 * <UL>
 *   <IMG src="doc-files/derived-gui.png">
 * </UL>
 * <P>
 * The building shown is the <I>Department of Electrical Engineering</I> (ESAT), at the Katholieke Universiteit Leuven, Belgium. 
 * <P>
 * Refer to the {@link JStandardGUIApplication} class for further information.
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 * 
 * @author  Sven Maerivoet
 * @version 16/08/2007
 * @see     JStandardGUIApplication
 */
public final class JDerivedGUIApplication extends JStandardGUIApplication implements ActionListener
{
	// the amount of time to explicitly wait during the splash screen show
	private static final int kSplashScreenWaitTimeMs = 1000;

	// internal datastructures
	private int fDateChooserID;
	private int fTimeChooserID;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JDerivedGUIApplication</CODE> object.
	 *
	 * @param argv an array of strings containing the <B>command-line</B> parameters
	 */
	public JDerivedGUIApplication(String argv[])
	{
		super(argv,null);
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 */
	public static void main(String[] argv)
	{
		new JDerivedGUIApplication(argv);
	}

	// the action-listener
	/**
	 */
	public void actionPerformed(ActionEvent e)
	{
		super.actionPerformed(e);

		String command = e.getActionCommand();

		if (command.equalsIgnoreCase(Messages.lookup("menuItemDateChooser",null))) {

			try {
				JDateChooser dateChooser = (JDateChooser) getGUIComponentCache().retrieveComponent(
						fDateChooserID);
				dateChooser.setDefaultDate(DateFormatter.getDate(11,4,1976));
				dateChooser.activate();

				if (dateChooser.canceled()) {
					JWarningDialog.warn(this,Messages.lookup("textChoiceCanceled",null));
				}
				else {
					JMessageDialog.show(this,Messages.lookup("textSelectedDate",
							new String[] {DateFormatter.getLongDateString(dateChooser.getSelectedDate())}));
				}
			}
			catch (DateTimeFormatException exc) {
			}
		}
		else if (command.equalsIgnoreCase(Messages.lookup("menuItemTimeChooser",null))) {
			try {
				JTimeChooser timeChooser = (JTimeChooser) getGUIComponentCache().retrieveComponent(
						fTimeChooserID);
				timeChooser.setDefaultTime(new Time(12,25,20,10));
				timeChooser.activate();

				if (timeChooser.canceled()) {
					JWarningDialog.warn(this,Messages.lookup("textChoiceCanceled",null));
				}
				else {
					JMessageDialog.show(this,Messages.lookup("textSelectedTime",
							new String[] {TimeFormatter.getHMSMsTimeString(timeChooser.getSelectedTime())}));
				}
			}
			catch (DateTimeFormatException exc) {
			}
		}
		else if (command.equalsIgnoreCase(Messages.lookup("menuItemIndex",null))) {
			JIncompleteWarningDialog.warn(this,
					"smtools.application.DerivedGUIApplication.actionPerformed()");
		}
	}

	/*********************
	 * PROTECTED METHODS *
	 *********************/

	/**
	 */
	protected String getInitialLookAndFeel()
	{
		return JStandardGUIApplication.klafPlatform;
	}

	/**
	 */
	protected final Dimension getInitialGUISize()
	{
		return (new Dimension(JStandardGUIApplication.kFullScreenGUI,
				JStandardGUIApplication.kFullScreenGUI));
	}

	/**
	 */
	protected boolean isGUIResizable()
	{
		return true;
	}

	/**
	 */
	protected String getWindowTitle()
	{
		return "smtools.application.JDerivedGUIApplication";
	}

	/**
	 */
	protected JLabel getCustomSplashScreenContent()
	{
		if (JDevelopMode.fModeActivated) {
			return null;
		}
		else {
			JLabel label = new JLabel("JDerivedGUIApplication",JLabel.LEFT);
			label.setFont(label.getFont().deriveFont(Font.BOLD).deriveFont(20.0f));
			return label;
		}
	}

	/**
	 */
	protected JAboutBox getAboutBox()
	{
		return (new JDerivedAboutBox(this));
	}

	/**
	 */
	protected void initializeClass(Object[] parameters)
	{
		getSplashScreen().setStatusMessage(Messages.lookup("textCachingCustomGUIComponents",null));

		// cache custom GUI components
		try {
			JDateChooser dateChooser = new JDateChooser(this,DateFormatter.getDate(0,0,0),
					JDateChooser.kEnableDefaultDate,JDefaultDialog.kPostponeActivation);
			fDateChooserID = getGUIComponentCache().addComponent(dateChooser);
		}
		catch (DateTimeFormatException exc) {
		}

		JTimeChooser timeChooser = new JTimeChooser(this,new Time(0,0,0,0),
				JTimeChooser.kHourMinuteSecondMillisecondType,JTimeChooser.kUse12HourClockDigits,
				JTimeChooser.kContinuousUpdate,JTimeChooser.kShowDigitalClock,
				JDefaultDialog.kPostponeActivation);
		fTimeChooserID = getGUIComponentCache().addComponent(timeChooser);

		if (!JDevelopMode.fModeActivated) {
			Chrono.wait(kSplashScreenWaitTimeMs);
		}
	}

	/**
	 */
	protected void constructContentPane(JPanel contentPane)
	{
		contentPane.setLayout(new BorderLayout());

		JImagePanel jip = null;
		try {
			/*****************************************************
 			 * KATHOLIEKE UNIVERSITEIT LEUVEN - ESAT-SCD (SISTA) *
 			 *****************************************************/
			/*
			jip = new JImagePanel("smtools-resources/images/esat.jpg");
			contentPane.add(jip,BorderLayout.CENTER);
			*/

			/*******************************
 			 * TRANSPORT & MOBILITY LEUVEN *
 			 *******************************/
			jip = new JImagePanel("smtools-resources/images/tmleuven.jpg");
			contentPane.add(jip,BorderLayout.CENTER);
		}
		catch (FileReadException exc) {
		}
	}

	/**
	 */
	protected JMenu[] constructMenus()
	{
		JMenu[] menus = new JMenu[1];
		JMenuItem menuItem = null;

		menus[0] = new JMenu(Messages.lookup("menuDemonstration",null));
		menus[0].setMnemonic(Messages.translateMnemonic(Messages.lookup("menuMnemonicDemonstration",
				null)));

		menuItem = new JMenuItem(Messages.lookup("menuItemDateChooser",null),Messages
				.translateMnemonic(Messages.lookup("menuItemMnemonicDateChooser",null)));
		menuItem.addActionListener(this);
		menus[0].add(menuItem);

		menuItem = new JMenuItem(Messages.lookup("menuItemTimeChooser",null),Messages
				.translateMnemonic(Messages.lookup("menuItemMnemonicTimeChooser",null)));
		menuItem.addActionListener(this);
		menus[0].add(menuItem);

		return menus;
	}

	/**
	 */
	protected JMenu constructRightHandMenu()
	{
		JMenu rightHandMenu = null;
		JMenuItem menuItem = null;

		rightHandMenu = new JMenu(Messages.lookup("menuHelp",null));
		rightHandMenu.setMnemonic(Messages.translateMnemonic(Messages.lookup("menuMnemonicHelp",null)));

		menuItem = new JMenuItem(Messages.lookup("menuItemIndex",null),Messages
				.translateMnemonic(Messages.lookup("menuItemMnemonicIndex",null)));
		menuItem.addActionListener(this);
		rightHandMenu.add(menuItem);

		return rightHandMenu;
	}

	/**
	 */
	protected boolean isClockShownInMenuBar()
	{
		return true;
	}

	/**
	 */
	protected boolean parseParameter(int paramNr, String parameter)
	{
		final String kCustomParameter = "PARAMETER";
		final String kCustomOption = "OPTION";

		String upperCaseParameter = parameter.toUpperCase();

		// parse parameter
		if (upperCaseParameter.startsWith(kCustomParameter + "=")) {
			String upperCaseOption = upperCaseParameter.substring(kCustomParameter.length() + 1);

			// parse option
			if (upperCaseOption.equalsIgnoreCase(kCustomOption)) {
				System.out.println("Parameter parsed.");
			}
			else {
				showParameterWarning(paramNr,parameter,"not a valid option");
			}

			// indicate that parameter was valid
			return true;
		}
		else {
			// indicate that parameter is unknown
			return false;
		}
	}

	/*****************
	 * INNER CLASSES *
	 *****************/

	private class JDerivedAboutBox extends JAboutBox
	{
		/****************
		 * CONSTRUCTORS *
		 ****************/

		JDerivedAboutBox(JFrame owner)
		{
			super(owner);
		}

		/*********************
		 * PROTECTED METHODS *
		 *********************/

		protected JLabel getLogo()
		{
			return (new JLabel(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/about.png",this,"errorAboutBoxImageNotFound")));
		}
		
		protected boolean getLogoPosition()
		{
			return JAboutBox.kLogoAtTop;
		}

		protected String getAboutText()
		{
			return
			("<B>JDerivedGUIApplication v1.1</B><BR><BR>" +
				"Copyright 2003-2007 Sven Maerivoet<BR>");
		}

		protected String getCopyrightFilename()
		{
			return "smtools-resources/licence/smtools-copyright.txt";
		}
	
		protected String getLicenceFilename()
		{
			return "smtools-resources/licence/smtools-apache-licence.txt";
		}

		protected JLabel[] getAffiliationsLabels()
		{
			/*****************************************************
 			 * KATHOLIEKE UNIVERSITEIT LEUVEN - ESAT-SCD (SISTA) *
 			 *****************************************************/
			/*
			JLabel[] affiliationsLabels = new JLabel[6];

			affiliationsLabels[0] = new JLabel(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/kuleuven-logo.jpg",this,"errorAboutBoxImageNotFound"),SwingConstants.LEFT);

			affiliationsLabels[1] = new JLabel("<html><b>http://www.kuleuven.be</b></html>");
			
			affiliationsLabels[2] = new JLabel(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/esat-logo.jpg",this,"errorAboutBoxImageNotFound"),SwingConstants.LEFT);

			affiliationsLabels[3] = new JLabel("<html><b>http://www.esat.kuleuven.be</b></html>");

			affiliationsLabels[4] = new JLabel(JImageLoader.loadImageIconWithWarning(
					"smtools-resources/images/sista-logo.jpg",this,"errorAboutBoxImageNotFound"),SwingConstants.LEFT);

			affiliationsLabels[5] = new JLabel("<html><b>http://www.esat.kuleuven.be/scd</b></html>");

			for (JLabel affiliationLabel : affiliationsLabels) { 
				affiliationLabel.setHorizontalTextPosition(SwingConstants.CENTER);
				affiliationLabel.setHorizontalAlignment(SwingConstants.LEFT);
				affiliationLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
				affiliationLabel.setVerticalAlignment(SwingConstants.BOTTOM);
			}

			return affiliationsLabels;
			*/

			/*******************************
 			 * TRANSPORT & MOBILITY LEUVEN *
 			 *******************************/

			JLabel[] affiliationsLabels = new JLabel[2];

			affiliationsLabels[0] = new JLabel(JImageLoader.loadImageIconWithWarning(
				"smtools-resources/images/tmleuven-logo-slogan.png",this,"errorAboutBoxImageNotFound"),SwingConstants.CENTER);

			affiliationsLabels[1] = new JLabel(
				"<html>" +
					"<b>Transport &amp; Mobility Leuven</b>" +
					"<p>Vital Decosterstraat 67A bus 0001" +
					"<p>3000 Leuven" +
					"<p>Belgium" +
					"<p>" +
					"<p>T: +32 (16) 31 77 30" +
					"<p>F: +32 (16) 31 77 39" +
					"<p>E: info@tmleuven.be" +
					"<p>W: http://www.tmleuven.be/" +
				"</html>");

			for (JLabel affiliationLabel : affiliationsLabels) { 
				affiliationLabel.setHorizontalTextPosition(SwingConstants.CENTER);
				affiliationLabel.setHorizontalAlignment(SwingConstants.LEFT);
				affiliationLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
				affiliationLabel.setVerticalAlignment(SwingConstants.BOTTOM);
			}

			return affiliationsLabels;

//			return null;
		}
	}
}
