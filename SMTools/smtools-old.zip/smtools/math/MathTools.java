// -------------------------------
// Filename      : MathTools.java
// Author        : Sven Maerivoet
// Last modified : 29/10/2004
// Target        : Java VM (1.6)
// -------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.math;

/**
 * The <CODE>MathTools</CODE> class offers some basic useful mathematical operations.
 * <P>
 * All methods in this class are static, so they should be invoked as:
 * <P>
 * <UL>
 *   <CODE>... = MathTools.method(...);</CODE>
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 29/10/2004
 */
public final class MathTools
{
	/****************
	 * CONSTRUCTORS *
	 ****************/

	// prevent instantiation
	private MathTools()
	{
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Calculates the square of a <CODE>double</CODE>.
	 *
	 * @param  x the <CODE>double</CODE> to be squared
	 * @return   the squared <CODE>double</CODE>
	 * @see    MathTools#cube(double)
	 */
	public static double sqr(double x)
	{
		return (x * x);
	}

	/**
	 * Calculates the cube of a <CODE>double</CODE>.
	 *
	 * @param  x the <CODE>double</CODE> to be cubed
	 * @return the cubed <CODE>double</CODE>
	 * @see    MathTools#sqr(double)
	 */
	public static double cube(double x)
	{
		return (x * x * x);
	}

	/**
	 * Calculates the arc tangent of the two <CODE>doubles</CODE>.
	 * <P>
	 * Both <CODE>doubles x</CODE> and <CODE>y</CODE> are used as y / x
	 * (<CODE>x</CODE> is allowed to be zero). The arc tangent will be a <B>positive angle</B>,
	 * lying in [0,2*PI]. The following cases are considered:
	 * <P>
	 * <UL>
	 *   <LI><CODE>x</CODE> >= 0, <CODE>y</CODE> >= 0: 0 <= <CODE>atan(x,y)</CODE> <= PI/2</LI>
	 *   <LI><CODE>x</CODE> <= 0, <CODE>y</CODE> >= 0: PI/2 <= <CODE>atan(x,y)</CODE> <= PI</LI>
	 *   <LI><CODE>x</CODE> <= 0, <CODE>y</CODE> <= 0: PI <= <CODE>atan(x,y)</CODE> <= 3*PI/2</LI>
	 *   <LI><CODE>x</CODE> >= 0, <CODE>y</CODE> <= 0: 3*PI/2 <= <CODE>atan(x,y)</CODE> <= 2*PI</LI>
	 * </UL>
	 * <P>
	 * With these two special cases:
	 * <P>
	 * <UL>
	 *   <LI><CODE>x</CODE> = 0, <CODE>y</CODE> > 0: <CODE>atan(x,y)</CODE> = PI/2</LI>
	 *   <LI><CODE>x</CODE> = 0, <CODE>y</CODE> < 0: <CODE>atan(x,y)</CODE> = 3*PI/2</LI>
	 * </UL>
	 *
	 * @param  x the denominator of the <CODE>double</CODE> to calculate the arc tangent of
	 * @param  y the numerator of the <CODE>double</CODE> to calculate the arc tangent of
	 * @return   the arc tangent of the <CODE>doubles</CODE>
	 */
	public static double atan(double x, double y)
	{
		double angle = 0.0;

		if (x == 0.0) {
			if (y > 0.0) {
				angle = Math.PI / 2.0;
			}
			else if (y < 0.0) {
				angle = 3.0 * (Math.PI / 2.0);
			}
		}
		else {
			double absAngle = Math.atan(Math.abs(y) / Math.abs(x));

			if ((x >= 0.0) && (y >= 0.0)) {
				angle = absAngle;
			}
			else if ((x <= 0.0) && (y >= 0.0)) {
				angle = Math.PI - absAngle;
			}
			else if ((x <= 0.0) && (y <= 0.0)) {
				angle = Math.PI + absAngle;
			}
			else {
				angle = (2.0 * Math.PI) - absAngle;
			}
		}

		return ((2.0 * Math.PI) - angle);
	}

	/**
	 * Clips an <CODE>int</CODE> between two extrema.
	 *
	 * @param  value   the <CODE>int</CODE> to clip between the two extrema
	 * @param  minimum the lower boundary to clip the <CODE>int</CODE>
	 * @param  maximum the upper boundary to clip the <CODE>int</CODE>
	 * @return         the <CODE>int</CODE> clipped between the two extrema
	 * @see MathTools#clip(double,double,double)
	 */
	public static int clip(int value, int minimum, int maximum)
	{
		return ((int) clip((double) value,(double) minimum,(double) maximum));
	}

	/**
	 * Clips a <CODE>double</CODE> between two extrema.
	 *
	 * @param  value   the <CODE>double</CODE> to clip between the two extrema
	 * @param  minimum the lower boundary to clip the <CODE>double</CODE>
	 * @param  maximum the upper boundary to clip the <CODE>double</CODE>
	 * @return         the <CODE>double</CODE> clipped between the two extrema
	 * @see MathTools#clip(int,int,int)
	 */
	public static double clip(double value, double minimum, double maximum)
	{
		if (value < minimum) {
			return minimum;
		}
		else if (value > maximum) {
			return maximum;
		}
		else {
			return value;
		}
	}

	/**
	 * Performs linear interpolation of a <CODE>double</CODE> with respect to two boundary values.
	 * <P>
	 * Usually, the specified <CODE>value</CODE> lies in the interval [0,1], with 0.0 corresponding to the
	 * lower boundary (<CODE>from</CODE>) and 1.0 to the upper boundary (<CODE>to</CODE>).
	 *
	 * @param  value the <CODE>double</CODE> to interpolate linearly with respect to two boundary values
	 * @param  from  the lower boundary to use for the linear interpolation (corresponding to <CODE>value</CODE> = 0.0)
	 * @param  to    the upper boundary to use for the linear interpolation (corresponding to <CODE>value</CODE> = 1.0)
	 * @return       the linear interpolation of the specified <CODE>double</CODE> between the two boundary values
	 */
	public static double linearInterpolation(double value, int from, int to)
	{
		return ((from * (1.0 - value)) + (to * value));
	}
}
