// -------------------------------
// Filename      : JSoundClip.java
// Author        : Sven Maerivoet
// Last modified : 02/02/2004
// Target        : Java VM (1.6)
// -------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.io.*;
import javax.sound.sampled.*;
import smtools.exceptions.*;

/**
 * The <CODE>JSoundClip</CODE> class provides capabilities for playing <I>short</I> soundfiles
 * (e.g., WAV, AU).
 * <P>
 * At the moment, only PCM encoded digital sound is supported (<I>so no MP3 yet !</I>).
 * <P>
 * Once the soundfile is loaded, it can be played using the non-blocking {@link JSoundClip#play()}
 * method. The playback can be stopped using the {@link JSoundClip#stop()} method. <I>If the caller wants
 * to play the soundfile again, the {@link JSoundClip#reset()} method should first be invoked.</I>
 * <P>
 * Refer to the {@link JSoundStream} class for streamed playback of longer soundfiles.
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 02/02/2004
 * @see     JSoundStream
 */
public final class JSoundClip
{
	// internal datastructures
	private Clip fClip;
	private boolean fClipOk;
	private long fClipDuration;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JSoundClip</CODE> object based on a specified soundfile.
	 *
	 * @param  filename               the name of the soundfile to load
	 * @throws FileReadException      if the specified soundfile cannot be read
	 * @throws SoundPlaybackException if the specified soundfile contains an unsupported digital audio format
	 *                                or if the system's resources could be allocated
	 */
	public JSoundClip(String filename) throws FileReadException, SoundPlaybackException
	{
		fClipDuration = 0;

		try {
			fClipOk = false;

			// check if file is readable
			File soundFile = new File(filename);
			if (!soundFile.canRead()) {
				throw (new IOException());
			}

			// obtain a handle to the datastream of the file
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);
			AudioFormat audioFormat = audioInputStream.getFormat();

			// construct a data line for the sound clip
			DataLine.Info info = new DataLine.Info(Clip.class,audioFormat);

			if (AudioSystem.isLineSupported(info)) {

				fClip = (Clip) AudioSystem.getLine(info);
				fClip.open(audioInputStream);
				fClipDuration = fClip.getMicrosecondLength();
				fClipOk = true;
			}
		}
		catch (IOException exc) {
			throw (new FileReadException(filename));
		}
		catch (UnsupportedAudioFileException exc) {
			throw (new SoundPlaybackException(filename));
		}
		catch (LineUnavailableException exc) {
			throw (new SoundPlaybackException(filename));
		}
	}

	/**************
	 * DESTRUCTOR *
	 **************/

	/**
	 * Class destructor.
	 */
	public final void finalize()
	{
		if (fClipOk) {
			fClip.close();
		}
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Resets the sound clip for playback.
	 * <P>
	 * This method does nothing if an exception was thrown by the constructor.
	 *
	 * @see JSoundClip#JSoundClip(String)
	 * @see JSoundClip#play()
	 * @see JSoundClip#stop()
	 */
	public void reset()
	{
		if (fClipOk) {
			fClip.setFramePosition(0);
		}
	}

	/**
	 * Starts playback of the loaded soundfile.
	 * <P>
	 * Once the playback has started, this method returns (i.e., non-blocking behavior).
	 * <P>
	 * This method does nothing if an exception was thrown by the constructor.
	 *
	 * @see JSoundClip#JSoundClip(String)
	 * @see JSoundClip#reset()
	 * @see JSoundClip#stop()
	 */
	public void play()
	{
		if (fClipOk) {
			fClip.start();
		}
	}

	/**
	 * Halts playback of the loaded soundfile.
	 * <P>
	 * This method does nothing if an exception was thrown by the constructor.
	 *
	 * @see JSoundClip#JSoundClip(String)
	 * @see JSoundClip#reset()
	 * @see JSoundClip#play()
	 */
	public void stop()
	{
		if (fClipOk) {
			fClip.stop();
		}
	}

	/**
	 * Returns the duration of the loaded soundfile.
	 * <P>
	 * This method returns 0 if an exception was thrown by the constructor.
	 *
	 * @return the duration of the loaded soundfile expressed in milliseconds
	 * @see    JSoundClip#JSoundClip(String)
	 */
	public long getDurationInMilliseconds()
	{
		return (fClipDuration / 1000);
	}
}
