// ------------------------------
// Filename      : Time.java
// Author        : Sven Maerivoet
// Last modified : 21/01/2004
// Target        : Java VM (1.6)
// ------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.util.*;

/**
 * The <CODE>Time</CODE> class acts as a container for time stamps.
 * <P>
 * A time stamp is defined by its hour, minute, second and millisecond.
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 21/01/2004
 */
public final class Time
{
	// the time's components
	/**
	 * hour component, lying in [0,23].
	 */
	public int fHour;

	/**
	 * The minute component, lying in [0,59].
	 */
	public int fMinute;

	/**
	 * The second component, lying in [0,59].
	 */
	public int fSecond;

	/**
	 * The millisecond component, lying in [0,999].
	 */
	public int fMillisecond;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>Time</CODE> object with all fields zero.
	 *
	 * @see Time#clear()
	 * @see Time#Time(int,int,int)
	 * @see Time#Time(int,int,int,int)
	 * @see Time#Time(long)
	 * @see Time#Time(Time)
	 */
	public Time()
	{
		clear();
	}

	/**
	 * Constructs a <CODE>Time</CODE> object with three specified fields.
	 * <P>
	 * The millisecond is set to zero.
	 *
	 * @param hour   the hour component
	 * @param minute the minute component
	 * @param second the second component
	 * @see   Time#Time()
	 * @see   Time#Time(int,int,int,int)
	 * @see   Time#Time(long)
	 * @see   Time#Time(Time)
	 */
	public Time(int hour, int minute, int second)
	{
		set(hour,minute,second,0);
	}

	/**
	 * Constructs a <CODE>Time</CODE> object with all fields specified.
	 *
	 * @param hour        the hour component
	 * @param minute      the minute component
	 * @param second      the second component
	 * @param millisecond the millisecond component
	 * @see   Time#Time()
	 * @see   Time#Time(int,int,int)
	 * @see   Time#Time(long)
	 * @see   Time#Time(Time)
	 */
	public Time(int hour, int minute, int second, int millisecond)
	{
		set(hour,minute,second,millisecond);
	}

	/**
	 * Constructs a <CODE>Time</CODE> object from a certain number of milliseconds.
	 *
	 * @param milliseconds                 the number of milliseconds to convert to a <CODE>Time</CODE> object
	 * @see   Time#convertFromMilliseconds
	 * @see   Time#Time()
	 * @see   Time#Time(int,int,int)
	 * @see   Time#Time(int,int,int, int)
	 * @see   Time#Time(Time)
	 */
	public Time(long milliseconds)
	{
		convertFromMilliseconds(milliseconds);
	}

	/**
	 * Constructs a <CODE>Time</CODE> object as a copy of another <CODE>Time</CODE> object.
	 * <P>
	 * This is the <B>copy constructor</B>.
	 *
	 * @param time the <CODE>Time</CODE> object to <B>deep copy</B>
	 * @see   Time#Time()
	 * @see   Time#Time(int,int,int)
	 * @see   Time#Time(int,int,int, int)
	 * @see   Time#Time(long)
	 */
	public Time(Time time)
	{
		set(time.fHour,time.fMinute,time.fSecond,time.fMillisecond);
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Clears all the fields, setting them to zero.
	 */
	public void clear()
	{
		set(0,0,0,0);
	}

	/**
	 * Sets all the fields to the specified values.
	 *
	 * @param hour        the hour component
	 * @param minute      the minute component
	 * @param second      the second component
	 * @param millisecond the millisecond component
	 */
	public void set(int hour, int minute, int second, int millisecond)
	{
		fHour = hour;
		fMinute = minute;
		fSecond = second;
		fMillisecond = millisecond;
	}

	/**
	 * Sets all fields according to the current system time.
	 */
	public void setCurrentTime()
	{
		Calendar calendar = Calendar.getInstance();
		fHour = calendar.get(Calendar.HOUR_OF_DAY);
		fMinute = calendar.get(Calendar.MINUTE);
		fSecond = calendar.get(Calendar.SECOND);
		fMillisecond = calendar.get(Calendar.MILLISECOND);
	}

	/**
	 * Checks the range of all the fields.
	 * <P>
	 * The domains of the various fields are:
	 * <P>
	 * <UL>
	 *   <LI>the hour component should lie in [0,23],</LI>
	 *   <LI>the minute and seconds components should lie in [0,59],</LI>
	 *   <LI>the millisecond component should lie in [0,999].</LI>
	 * </UL>
	 *
	 * @return <CODE>true</CODE> if all the fields are valid, <CODE>false</CODE> otherwise
	 */
	public boolean isValid()
	{
		return ((fHour >= 0) && (fHour <= 23) || (fMinute >= 0) && (fMinute <= 59) || (fSecond >= 0)
				&& (fSecond <= 59) || (fMillisecond >= 0) && (fMillisecond <= 999));
	}

	/**
	 * Converts all the fields to a cumulative millisecond representation.
	 * <P>
	 * All fields are converted to milliseconds and summed together.
	 *
	 * @return the number of milliseconds corresponding to this <CODE>Time</CODE> object
	 */
	public long convertToMilliseconds()
	{
		return (fMillisecond + (fSecond * 1000) + (fMinute * 1000 * 60) + (fHour * 1000 * 60 * 60));
	}

	/**
	 * Calculates all the fields based on a cumulative millisecond representation.
	 *
	 * @param milliseconds the number of milliseconds to convert to a <CODE>Time</CODE> object
	 */
	public void convertFromMilliseconds(long milliseconds)
	{
		long mls = milliseconds;

		fHour = (int) (mls / (1000 * 60 * 60));
		mls %= (1000 * 60 * 60);

		fMinute = (int) (mls / (1000 * 60));
		mls %= (1000 * 60);

		fSecond = (int) (mls / 1000);

		fMillisecond = (int) (mls % 1000);
	}
}
