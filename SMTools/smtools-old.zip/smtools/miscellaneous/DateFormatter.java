// ----------------------------------
// Filename      : DateFormatter.java
// Author        : Sven Maerivoet
// Last modified : 23/07/2007
// Target        : Java VM (1.6)
// ----------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.text.*;
import java.util.*;
import smtools.exceptions.*;
import smtools.application.util.*;

/**
 * The <CODE>DateFormatter</CODE> class converts <CODE>Date</CODE> objects to and from strings.
 * <P>
 * Note that a valid {@link Messages} database must be available !
 * <P>
 * It also supports conversion to language-specific day and month names.
 * All methods in this class are static, so they should be invoked as:
 * <P>
 * <UL>
 *   <CODE>... = DateFormatter.method(...);</CODE>
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 21/01/2004
 */
public final class DateFormatter
{
	// the date format specifier
	private static final String kDateFormatSpecifier = "dd/MM/yyyy";

	/****************
	 * CONSTRUCTORS *
	 ****************/

	// prevent instantiation
	private DateFormatter()
	{
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Constructs a <CODE>Date</CODE> object with user specified fields.
	 *
	 * @param  day   the day to set
	 * @param  month the month to set
	 * @param  year  the year to set
	 * @return       a <CODE>Date</CODE> object corresponding to the specified fields
	 * @throws DateTimeFormatException if at least one of the specified fields is invalid
	 */
	public static Date getDate(int day, int month, int year) throws DateTimeFormatException
	{
		// convert date to a string
		String dateString = String.valueOf(day);
		if (day < 10) {
			dateString = "0" + dateString;
		}
		dateString += "/";

		String dummy = String.valueOf(month);
		if (month < 10) {
			dummy = "0" + dummy;
		}
		dateString += dummy + "/" + String.valueOf(year);

		return getDate(dateString);
	}

	/**
	 * Converts a string to a <CODE>Date</CODE> object.
	 * <P>
	 * The string has to have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>dd:mm:yyyy</B>, e.g., 11/04/1976
	 * </UL>
	 *
	 * @param  dateString the string to convert
	 * @return            a <CODE>Date</CODE> object corresponding to the specified string
	 * @throws DateTimeFormatException if the specified string was not in the right format
	 */
	public static Date getDate(String dateString) throws DateTimeFormatException
	{
		// try to parse the string into a date
		SimpleDateFormat dateFormatter = new SimpleDateFormat(kDateFormatSpecifier);
		ParsePosition parsePosition = new ParsePosition(0);

		Date date = dateFormatter.parse(dateString,parsePosition);

		if (parsePosition.getErrorIndex() != -1) {
			throw (new DateTimeFormatException(dateString));
		}

		return date;
	}

	/**
	 * Converts a <CODE>Date</CODE> object to a compact string.
	 * <P>
	 * The string will have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>dd:mm:yyyy</B>, e.g., 11/04/1976
	 * </UL>
	 *
	 * @param  date the <CODE>Date</CODE> object to convert
	 * @return      a string corresponding to the specified <CODE>Date</CODE> object
	 */
	public static String getShortDateString(Date date)
	{
		SimpleDateFormat dateFormatter = new SimpleDateFormat(kDateFormatSpecifier);
		return dateFormatter.format(date);
	}

	/**
	 * Converts a <CODE>Date</CODE> object to a full string.
	 * <P>
	 * The string will have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>day-of-week, month dd, yyyy</B>, e.g., Sunday, April 11, 1976
	 * </UL>
	 * <P>
	 * Note that a valid {@link Messages} database must be available !
	 *
	 * @param  date the <CODE>Date</CODE> object to convert
	 * @return      a string corresponding to the specified <CODE>Date</CODE> object
	 * @see    Messages
	 * @see    DateFormatter#getDayString(int)
	 * @see    DateFormatter#getMonthString(int)
	 */
	public static String getLongDateString(Date date)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		String dayOfWeekString = getDayString(calendar.get(Calendar.DAY_OF_WEEK));
		String dayString = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
		String monthString = getMonthString(calendar.get(Calendar.MONTH));
		String yearString = String.valueOf(calendar.get(Calendar.YEAR));

		return
			dayOfWeekString.substring(0,1).toUpperCase() + dayOfWeekString.substring(1) + ", " +
			monthString.substring(0,1).toUpperCase() + monthString.substring(1) + " " +
			dayString + ", " + yearString;
	}

	/**
	 * Converts a day-of-week index to a weekday name.
	 * <P>
	 * As for the day-of-week, 1 corresponds to sunday, 2 to monday, ... and 7 to saturday.
	 * <P>
	 * Note that a valid {@link Messages} database must be available !
	 *
	 * @param  day the day-of-week index to convert
	 * @return     a string corresponding to the weekday name
	 * @see    Messages
	 */
	public static String getDayString(int day)
	{
		switch (day) {
			case 1:
				return Messages.lookup("textDaySunday",null);
			case 2:
				return Messages.lookup("textDayMonday",null);
			case 3:
				return Messages.lookup("textDayTuesday",null);
			case 4:
				return Messages.lookup("textDayWednesday",null);
			case 5:
				return Messages.lookup("textDayThursday",null);
			case 6:
				return Messages.lookup("textDayFriday",null);
			case 7:
				return Messages.lookup("textDaySaturday",null);
		}

		return "";
	}

	/**
	 * Converts a month index to a month name.
	 * <P>
	 * As for the month index, 0 corresponds to january, 1 to february, ... and 11 to december.
	 * <P>
	 * Note that a valid {@link Messages} database must be available !
	 *
	 * @param  month the month index to convert
	 * @return       a string corresponding to the month name
	 * @see    Messages
	 */
	public static String getMonthString(int month)
	{
		switch (month) {
			case 0:
				return Messages.lookup("textMonthJanuary",null);
			case 1:
				return Messages.lookup("textMonthFebruary",null);
			case 2:
				return Messages.lookup("textMonthMarch",null);
			case 3:
				return Messages.lookup("textMonthApril",null);
			case 4:
				return Messages.lookup("textMonthMay",null);
			case 5:
				return Messages.lookup("textMonthJune",null);
			case 6:
				return Messages.lookup("textMonthJuly",null);
			case 7:
				return Messages.lookup("textMonthAugust",null);
			case 8:
				return Messages.lookup("textMonthSeptember",null);
			case 9:
				return Messages.lookup("textMonthOctober",null);
			case 10:
				return Messages.lookup("textMonthNovember",null);
			case 11:
				return Messages.lookup("textMonthDecember",null);
		}

		return "";
	}

	/**
	 * Converts a month name to a month index.
	 * <P>
	 * As for the month name, january corresponds to 1, february to 2, ... and  december to 11.
	 * <P>
	 * Note that a valid {@link Messages} database must be available !
	 *
	 * @param  month the month name to convert
	 * @return       a number corresponding to the month index
	 * @see    Messages
	 */
	public static int getMonthID(String month)
	{
		if (month.equalsIgnoreCase(Messages.lookup("textMonthJanuary",null))) {
			return 1;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthFebruary",null))) {
			return 2;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthMarch",null))) {
			return 3;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthApril",null))) {
			return 4;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthMay",null))) {
			return 5;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthJune",null))) {
			return 6;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthJuly",null))) {
			return 7;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthAugust",null))) {
			return 8;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthSeptember",null))) {
			return 9;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthOctober",null))) {
			return 10;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthNovember",null))) {
			return 11;
		}
		else if (month.equalsIgnoreCase(Messages.lookup("textMonthDecember",null))) {
			return 12;
		}

		return 1;
	}
}
