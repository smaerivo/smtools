// -----------------------------------
// Filename      : TextFileWriter.java
// Author        : Sven Maerivoet
// Last modified : 22/01/2004
// Target        : Java VM (1.6)
// -----------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.io.*;
import java.util.*;
import smtools.exceptions.*;

/**
 * The <CODE>TextFileWriter</CODE> class allows easy writing to text files.
 * <P>
 * In the resulting text file, each line will contain at most one value.
 * <P>
 * The available datatypes to write are:
 * <UL>
 *   <LI><CODE>int</CODE></LI>
 *   <LI><CODE>double</CODE></LI>
 *   <LI><CODE>String</CODE> (unquoted)</LI>
 *   <LI><CODE>boolean</CODE> (true and false)</LI>
 *   <LI><CODE>Date</CODE> (dd:mm:yyyy)</LI>
 *   <LI><CODE>Time</CODE> (hh:mm:ss:mls)</LI>
 * </UL>
 *
 * @author  Sven Maerivoet
 * @version 22/01/2004
 */
public class TextFileWriter
{
	// internal datastructures
	private PrintWriter fFileWriter;
	private String fFilename;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Sets up a text file writer for the specified file.
	 *
	 * @param  filename                   the name of the file to create
	 * @throws FileCantBeCreatedException if the file cannot be created
	 */
	public TextFileWriter(String filename) throws FileCantBeCreatedException
	{
		this(filename,false);
	}

	/**
	 * Sets up a text file writer for the specified file.
	 *
	 * @param  filename                   the name of the file to create
	 * @param  append                     whether or not the (existing) file should be appended
	 * @throws FileCantBeCreatedException if the file cannot be created
	 */
	public TextFileWriter(String filename, boolean append) throws FileCantBeCreatedException
	{
		fFilename = filename;

		try {
			// try to create the file
			FileOutputStream fileOutputStream = new FileOutputStream(fFilename,append);
			fFileWriter = new PrintWriter(fileOutputStream);
		}
		catch (IOException exc) {
			throw (new FileCantBeCreatedException(fFilename));
		}
	}

	/**************
	 * DESTRUCTOR *
	 **************/

	/**
	 * Class destructor.
	 */
	public final void finalize()
	{
		fFileWriter.close();
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Writes an empty line to the file.
	 *
	 * @throws FileWriteException if an error during the writing occurred
	 */
	public final void writeLn() throws FileWriteException
	{
		fFileWriter.println();

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,""));
		}
	}

	/**
	 * Writes a string representation of an <CODE>int</CODE> to the file.
	 *
	 * @param  i                  the <CODE>int</CODE> to write to the file
	 * @throws FileWriteException if the <CODE>int</CODE> could not be written to the file
	 */
	public final void writeInt(int i) throws FileWriteException
	{
		fFileWriter.print(i);

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,String.valueOf(i)));
		}
	}

	/**
	 * Writes a string representation of a <CODE>double</CODE> to the file.
	 *
	 * @param  d                  the <CODE>double</CODE> to write to the file
	 * @throws FileWriteException if the <CODE>double</CODE> could not be written to the file
	 */
	public final void writeDouble(double d) throws FileWriteException
	{
		fFileWriter.print(d);

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,String.valueOf(d)));
		}
	}

	/**
	 * Writes a string to the file.
	 *
	 * @param  s                  the <CODE>String</CODE> to write to the file
	 * @throws FileWriteException if the <CODE>String</CODE> could not be written to the file
	 */
	public final void writeString(String s) throws FileWriteException
	{
		fFileWriter.print(s);

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,s));
		}
	}

	/**
	 * Writes a string representation of a <CODE>boolean</CODE> to the file.
	 * <P>
	 * The string representation is either <B>TRUE</B> or <B>FALSE</B>.
	 *
	 * @param  b                  the <CODE>boolean</CODE> to write to the file
	 * @throws FileWriteException if the <CODE>boolean</CODE> could not be written to the file
	 */
	public final void writeBoolean(boolean b) throws FileWriteException
	{
		String boolString = "FALSE";
		if (b) {
			boolString = "TRUE";
		}
		fFileWriter.print(boolString);

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,boolString));
		}
	}

	/**
	 * Writes a string representation of a <CODE>Date</CODE> object to the file.
	 * <P>
	 * The string representation of the <CODE>Date</CODE> object is
	 * <B>dd:mm:yyyy</B>, e.g., "11/04/1976".
	 *
	 * @param  date               the <CODE>Date</CODE> object to write to the file
	 * @throws FileWriteException if the <CODE>Date</CODE> object could not be written to the file
	 */
	public final void writeDate(Date date) throws FileWriteException
	{
		String dateString = DateFormatter.getShortDateString(date);
		fFileWriter.print(dateString);

		if (fFileWriter.checkError()) {
			throw (new FileWriteException(fFilename,dateString));
		}
	}

	/**
	 * Writes a string representation of a <CODE>Time</CODE> object to the file.
	 * <P>
	 * The string representation of the <CODE>Time</CODE> object is
	 * <B>hh:mm:ss.mls</B>, e.g., "12:45:16.154".
	 *
	 * @param  time               the <CODE>Time</CODE> object to write to the file
	 * @throws FileWriteException if the <CODE>Time</CODE> object could not be written to the file
	 */
	public final void writeTime(Time time) throws FileWriteException
	{
		try {
			String timeString = TimeFormatter.getHMSMsTimeString(time);
			fFileWriter.print(timeString);

			if (fFileWriter.checkError()) {
				throw (new FileWriteException(fFilename,timeString));
			}
		}
		catch (DateTimeFormatException exc) {
			throw (new FileWriteException(fFilename,exc.getDateTimeString()));
		}
	}
}
