// ----------------------------------
// Filename      : TimeFormatter.java
// Author        : Sven Maerivoet
// Last modified : 31/10/2004
// Target        : Java VM (1.6)
// ----------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import smtools.exceptions.*;

/**
 * The <CODE>TimeFormatter</CODE> class converts <CODE>Time</CODE> objects to and from strings.
 * <P>
 * All methods in this class are static, so they should be invoked as:
 * <P>
 * <UL>
 *   <CODE>... = TimeFormatter.method(...);</CODE>
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 31/10/2004
 */
public final class TimeFormatter
{
	/****************
	 * CONSTRUCTORS *
	 ****************/

	// prevent instantiation
	private TimeFormatter()
	{
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Converts a string to a <CODE>Time</CODE> object.
	 * <P>
	 * The string has to have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>hh:mm:ss.mls</B>, e.g., 12:45:16.154
	 * </UL>
	 *
	 * @param  timeString              the string to convert
	 * @return                         a <CODE>Time</CODE> object corresponding to the specified string
	 * @throws DateTimeFormatException if the specified string was not in the right format,
	 *                                 or if the <CODE>Time</CODE> object's fields are invalid
	 * @see    Time#isValid()
	 */
	public static Time getTime(String timeString) throws DateTimeFormatException
	{
		Time time = new Time();
		String dummy = timeString;

		// separate the time-string's components
		int separatorPos = dummy.indexOf(':');
		String hourString = dummy.substring(0,separatorPos);
		dummy = dummy.substring(separatorPos + 1);

		separatorPos = dummy.indexOf(':');
		String minuteString = dummy.substring(0,separatorPos);
		dummy = dummy.substring(separatorPos + 1);

		separatorPos = dummy.indexOf('.');
		String secondString = dummy.substring(0,separatorPos);
		dummy = dummy.substring(separatorPos + 1);

		String millisecondString = dummy.substring(0);

		// try to convert the hour component
		try {
			time.fHour = Integer.parseInt(hourString);
		}
		catch (NumberFormatException exc) {
			throw (new DateTimeFormatException(timeString));
		}

		// try to convert the minute component
		try {
			time.fMinute = Integer.parseInt(minuteString);
		}
		catch (NumberFormatException exc) {
			throw (new DateTimeFormatException(timeString));
		}

		// try to convert the second component
		try {
			time.fSecond = Integer.parseInt(secondString);
		}
		catch (NumberFormatException exc) {
			throw (new DateTimeFormatException(timeString));
		}

		// try to convert the millisecond component
		try {
			time.fMillisecond = Integer.parseInt(millisecondString);
		}
		catch (NumberFormatException exc) {
			throw (new DateTimeFormatException(timeString));
		}

		if (!time.isValid()) {
			throw (new DateTimeFormatException(timeString));
		}

		return time;
	}

	/**
	 * Converts a <CODE>Time</CODE> object to a string.
	 * <P>
	 * The string will have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>hh:mm:ss.mls</B>, e.g., 12:45:16.154
	 * </UL>
	 *
	 * @param  time                    the <CODE>Time</CODE> object to convert
	 * @return                         a <CODE>Time</CODE> object corresponding to the specified string
	 * @throws DateTimeFormatException if the <CODE>Time</CODE> object's fields are invalid
	 * @see    Time#isValid()
	 */
	public static String getHMSMsTimeString(Time time) throws DateTimeFormatException
	{
		// convert timestamp to a string
		String timeString = String.valueOf(time.fHour);
		if (time.fHour < 10) {
			timeString = "0" + timeString;
		}
		timeString += ":";

		String dummy = String.valueOf(time.fMinute);
		if (time.fMinute < 10) {
			dummy = "0" + dummy;
		}
		timeString += (dummy + ":");

		dummy = String.valueOf(time.fSecond);
		if (time.fSecond < 10) {
			dummy = "0" + dummy;
		}
		timeString += (dummy + ".");

		dummy = String.valueOf(time.fMillisecond);
		if (time.fMillisecond < 100) {
			dummy = "0" + dummy;
		}
		if (time.fMillisecond < 10) {
			dummy = "0" + dummy;
		}
		timeString += dummy;

		if (!time.isValid()) {
			throw (new DateTimeFormatException(timeString));
		}

		return timeString;
	}

	/**
	 * Converts a <CODE>Time</CODE> object to a string.
	 * <P>
	 * The string will have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>hh:mm:ss</B>, e.g., 12:45:16
	 * </UL>
	 *
	 * @param  time                    the <CODE>Time</CODE> object to convert
	 * @return                         a <CODE>Time</CODE> object corresponding to the specified string
	 * @throws DateTimeFormatException if the <CODE>Time</CODE> object's fields are invalid
	 * @see    Time#isValid()
	 */
	public static String getHMSTimeString(Time time) throws DateTimeFormatException
	{
		String timeString = getHMSMsTimeString(time);
		return timeString.substring(0,timeString.length() - 4);
	}

	/**
	 * Converts a <CODE>Time</CODE> object to a string.
	 * <P>
	 * The string will have the following specific format:
	 * <P>
	 * <UL>
	 *   <B>hh:mm</B>, e.g., 12:45
	 * </UL>
	 *
	 * @param  time                    the <CODE>Time</CODE> object to convert
	 * @return                         a <CODE>Time</CODE> object corresponding to the specified string
	 * @throws DateTimeFormatException if the <CODE>Time</CODE> object's fields are invalid
	 * @see    Time#isValid()
	 */
	public static String getHMTimeString(Time time) throws DateTimeFormatException
	{
		String timeString = getHMSTimeString(time);
		return timeString.substring(0,timeString.length() - 3);
	}
}
