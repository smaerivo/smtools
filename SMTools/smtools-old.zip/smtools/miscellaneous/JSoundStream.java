// ---------------------------------
// Filename      : JSoundStream.java
// Author        : Sven Maerivoet
// Last modified : 02/02/2004
// Target        : Java VM (1.6)
// ---------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.io.*;
import javax.sound.sampled.*;
import smtools.exceptions.*;

/**
 * The <CODE>JSoundStream</CODE> class provides capabilities for playing soundfiles
 * (e.g., WAV, AU).
 * <P>
 * At the moment, only PCM encoded digital sound is supported (<I>so no MP3 yet !</I>).
 * <P>
 * Once a <CODE>JSoundStream</CODE> object is successfully initialized, playback automatically
 * starts (a separate thread is created to allow streaming of the soundfile).
 * <P>
 * <B><U>Important remark</U></B>
 * <P>
 * <UL>
 *   <I>The soundfile can only played once ! If the caller wants to play the soundfile multiple
 *   times, the {@link JSoundClip} class should be used instead.</I>
 * </UL>
 * <P>
 * <B>Note that this class cannot be subclassed !</B>
 *
 * @author  Sven Maerivoet
 * @version 02/02/2004
 * @see     JSoundClip
 */
public final class JSoundStream
{
	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Constructs a <CODE>JSoundStream</CODE> object based on a specified soundfile.
	 * <P>
	 * Note that once the soundfile is successfully loaded, playback is automatically initiated !
	 *
	 * @param  filename               the name of the soundfile to load
	 * @throws FileReadException      if the specified soundfile cannot be read
	 * @throws SoundPlaybackException if the specified soundfile contains an unsupported digital audio format
	 *                                or if the playback failed (e.g., busy system resources, ...)
	 */
	public JSoundStream(String filename) throws FileReadException, SoundPlaybackException
	{
		try {
			// check if file is readable
			File soundFile = new File(filename);
			if (!soundFile.canRead()) {
				throw (new IOException());
			}

			// obtain a handle to the datastream of the file
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);
			AudioFormat audioFormat = audioInputStream.getFormat();

			// construct a data line for the sound file
			DataLine.Info info = new DataLine.Info(SourceDataLine.class,audioFormat);

			if (AudioSystem.isLineSupported(info)) {

				SourceDataLine sourceDataLine = (SourceDataLine) AudioSystem.getLine(info);
				new PlayThread(sourceDataLine,audioFormat,audioInputStream).start();
			}
		}
		catch (IOException exc) {
			throw (new FileReadException(filename));
		}
		catch (UnsupportedAudioFileException exc) {
			throw (new SoundPlaybackException(filename));
		}
		catch (LineUnavailableException exc) {
			throw (new SoundPlaybackException(filename));
		}
	}

	/*****************
	 * INNER CLASSES *
	 *****************/

	private class PlayThread extends Thread
	{
		// internal datastructures
		private SourceDataLine fSourceDataLine;
		private AudioFormat fAudioFormat;
		private AudioInputStream fAudioInputStream;
		private byte[] fBuffer;

		/****************
		 * CONSTRUCTORS *
		 ****************/
		public PlayThread(SourceDataLine sourceDataLine, AudioFormat audioFormat,
				AudioInputStream audioInputStream)
		{
			fSourceDataLine = sourceDataLine;
			fAudioFormat = audioFormat;
			fAudioInputStream = audioInputStream;
			fBuffer = new byte[10000];
		}

		/******************
		 * PUBLIC METHODS *
		 ******************/

		public void run()
		{
			try {
				fSourceDataLine.open(fAudioFormat);
				fSourceDataLine.start();

				int nrOfBytesRead = 0;

				// read all data from the input stream
				while ((nrOfBytesRead = fAudioInputStream.read(fBuffer,0,fBuffer.length)) != -1) {

					if (nrOfBytesRead > 0) {

						// transfer data to the internal buffer of the data line
						fSourceDataLine.write(fBuffer,0,nrOfBytesRead);
					}
				}

				// wait for the internal buffer of the data line to empty
				fSourceDataLine.drain();
				fSourceDataLine.close();
			}
			catch (Exception e) {
			}
		}
	}
}
