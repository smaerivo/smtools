// -----------------------------------
// Filename      : TextFileParser.java
// Author        : Sven Maerivoet
// Last modified : 06/06/2007
// Target        : Java VM (1.6)
// -----------------------------------

/**
 * Copyright 2003-2007 Sven Maerivoet
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package smtools.miscellaneous;

import java.io.*;
import java.util.*;
import smtools.exceptions.*;

/**
 * The <CODE>TextFileParser</CODE> class allows easy parsing of text files.
 * <P>
 * In the text file to parse, each line may contain at most one value.
 * <P>
 * The recognised datatypes are:
 * <UL>
 *   <LI><CODE>int</CODE></LI>
 *   <LI><CODE>double</CODE></LI>
 *   <LI><CODE>String</CODE> (unquoted)</LI>
 *   <LI><CODE>boolean</CODE> (yes, true, no and false)</LI>
 *   <LI><CODE>Date</CODE> (dd:mm:yyyy)</LI>
 *   <LI><CODE>Time</CODE> (hh:mm:ss:mls)</LI>
 * </UL>
 *
 * @author  Sven Maerivoet
 * @version 26/01/2004
 */
public class TextFileParser
{
	// internal datastructures
	private RandomAccessFile fFileToParse;
	private String fFilename;
	private int fLineNr;

	/****************
	 * CONSTRUCTORS *
	 ****************/

	/**
	 * Sets up a text file parser for the specified file.
	 *
	 * @param  filename                  the name of the file to parse
	 * @throws FileDoesNotExistException if the file is not found
	 */
	public TextFileParser(String filename) throws FileDoesNotExistException
	{
		fFilename = filename;
		fLineNr = 0;

		try {
			// try to open the file
			fFileToParse = new RandomAccessFile(fFilename,"r");
		}
		catch (IOException exc) {
			throw (new FileDoesNotExistException(filename));
		}
	}

	/**************
	 * DESTRUCTOR *
	 **************/

	/**
	 * Class destructor.
	 */
	public final void finalize()
	{
		try {
			fFileToParse.close();
		}
		catch (IOException exc) {
		}
	}

	/******************
	 * PUBLIC METHODS *
	 ******************/

	/**
	 * Returns whether or not the parsing has reached the end of the file.
	 *
	 * @return <CODE>true</CODE> if the end of the file is reached, <CODE>false</CODE> otherwise
	 */
	public final boolean endOfFileReached()
	{
		boolean eofReached = false;
		try {
			eofReached = (fFileToParse.getFilePointer() >= fFileToParse.length());
		}
		catch (IOException exc) {
		}

		return eofReached;
	}

	/**
	 * Moves the internal file pointer to the beginning of the file.
	 */
	public final void rewind()
	{
		try {
			// move file pointer to the beginning
			fFileToParse.seek(0);
		}
		catch (IOException exc) {
		}
	}

	/**
	 * Reads a <CODE>byte</CODE> from the file.
	 *
	 * @return the <CODE>byte</CODE> read
	 * @throws FileParseException if the <CODE>byte</CODE> could not be read
	 */
	public final byte readByte() throws FileParseException
	{
		try {
			Byte byteRead = fFileToParse.readByte();

			return byteRead.byteValue();
		}
		catch (IOException exc) {
			throw (new FileParseException(fFilename,"",fLineNr));
		}
	}

	/**
	 * Reads a 8-bit <CODE>char</CODE> from the file.
	 *
	 * @return the 8-bit <CODE>char</CODE> read
	 * @throws FileParseException if the 8-bit <CODE>char</CODE> could not be read
	 */
	public final char readChar() throws FileParseException
	{
		return ((char) readByte());
	}

	/**
	 * Reads a line from the file and tries to parse it as an <CODE>int</CODE>.
	 *
	 * @return the line parsed as an <CODE>int</CODE>
	 * @throws FileParseException if an invalid number was specified or the line could not be read
	 */
	public final int readInt() throws FileParseException
	{
		String stringRead = readString();

		int nrRead = 0;

		try {
			nrRead = (Integer.valueOf(stringRead)).intValue();

			return nrRead;
		}
		catch (NumberFormatException exc) {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}
	}

	/**
	 * Reads a line from the file and tries to parse it as a <CODE>double</CODE>.
	 *
	 * @return the line parsed as a <CODE>double</CODE>
	 * @throws FileParseException if an invalid number was specified or the line could not be read
	 */
	public final double readDouble() throws FileParseException
	{
		String stringRead = readString();

		double nrRead = 0.0;

		try {
			nrRead = (Double.valueOf(stringRead)).doubleValue();

			return nrRead;
		}
		catch (NumberFormatException exc) {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}
	}

	/**
	 * Reads a line from the file and converts it to a <CODE>String</CODE> object.
	 *
	 * @return the line converted to a <CODE>String</CODE> object
	 * @throws FileParseException if the line could not be read
	 */
	public final String readString() throws FileParseException
	{
		String stringRead = "";

		try {
			++fLineNr;
			stringRead = fFileToParse.readLine();
			if (stringRead != null) {
				stringRead.trim();
			}
			else {
				stringRead = "";
			}

			return stringRead;
		}
		catch (IOException exc) {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}
	}

	/**
	 * Reads a line from the file and parses it as a <CODE>boolean</CODE>.
	 * <P>
	 * The following truth values are recognised:
	 * <P>
	 * <UL>
	 *   <LI><B>yes</B></LI>
	 *   <LI><B>true</B></LI>
	 *   <LI><B>no</B></LI>
	 *   <LI><B>false</B></LI>
	 * </UL>
	 *
	 * @return the line parsed as a <CODE>boolean</CODE>
	 * @throws FileParseException if an invalid truth values was specified or the line could not be read
	 */
	public final boolean readBoolean() throws FileParseException
	{
		String stringRead = readString();

		boolean booleanRead = false;

		if (stringRead.equalsIgnoreCase("YES") || stringRead.equalsIgnoreCase("TRUE")) {
			booleanRead = true;
		}
		if (stringRead.equalsIgnoreCase("NO") || stringRead.equalsIgnoreCase("FALSE")) {
			booleanRead = false;
		}
		else {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}

		return booleanRead;
	}

	/**
	 * Reads a line from the file and parses it as a <CODE>Date</CODE> object.
	 * <P>
	 * The specified date should have the following format:
	 * <P>
	 * <UL>
	 *   <B>dd:mm:yyyy</B>, e.g., 11/04/1976
	 * </UL>
	 *
	 * @return the line parsed as a <CODE>Date</CODE> object
	 * @throws FileParseException if an invalid date was specified or the line could not be read
	 * @see    DateFormatter#getDate(String)
	 */
	public final Date readDate() throws FileParseException
	{
		String stringRead = readString();

		// try to parse the string into a date
		Date date = null;
		try {
			date = DateFormatter.getDate(stringRead);

			return date;
		}
		catch (DateTimeFormatException exc) {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}
	}

	/**
	 * Reads a line from the file and parses it as a <CODE>Time</CODE> object.
	 * <P>
	 * The specified time should have the following format:
	 * <P>
	 * <UL>
	 *   <B>hh:mm:ss.mls</B>, e.g., 12:45:16.154
	 * </UL>
	 *
	 * @return the line parsed as a <CODE>Time</CODE> object
	 * @throws FileParseException if an invalid time was specified or the line could not be read
	 * @see    TimeFormatter#getTime(String)
	 */
	public final Time readTime() throws FileParseException
	{
		String stringRead = readString();

		// try to parse the string into a date
		Time time = null;
		try {
			time = TimeFormatter.getTime(stringRead);

			return time;
		}
		catch (DateTimeFormatException exc) {
			throw (new FileParseException(fFilename,stringRead,fLineNr));
		}
	}

	/**
	 * Returns what percentage of the file has been read (between 0.0 and 100.0).
	 *
	 * @return the percentage of the file that has been read as a <CODE>double</CODE> between 0.0 and 100.0
	 */
	public final double getPercentageRead()
	{
		try {
			return (((double) fFileToParse.getFilePointer() / (double) fFileToParse.length()) * 100.0);
		}
		catch (IOException exc) {
			// ignore exception
			return 0.0;
		}
	}
}
